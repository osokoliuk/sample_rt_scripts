from pylab import *

import pycool

cool = pycool.cooler()

#--------------

z = 0.0
temp = 1.0e4
Delta = 1.0

cool.set_photo_rates_from_uvb(z)
cool.set_coefficients(temp, z)
print("nH_comov_mean =", cool.nHcgs_comov_mean)

#--------------

u, nHcgs, n_H0, n_Hp, n_He0, n_Hep, n_Hepp, n_e, mean_mw = cool.find_eq_state_from_temp(Delta,z,temp)

print("n_HI / n_H =", n_H0)
print("n_e / n_H =", n_e)
