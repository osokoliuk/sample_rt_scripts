from pylab import *
import time

from scipy.constants import parsec as pc
from scipy.constants import m_p as mproton_si
from scipy.constants import k as kboltzmann_si
from scipy.constants import eV
Mpc = 1.0e6 * pc
msun = 1.9884430e30
mproton_cgs = mproton_si * 1000.0
kboltzmann_cgs = kboltzmann_si * 1.0e7

#----------------------------------------

# Verner & Ferland case-A recombination rate fit coefficients
a_vf96 = array([7.982e-11, 9.356e-10, 1.891e-10])
b_vf96 = array([0.7480   , 0.7892   , 0.7524])
T0_vf96 = array([3.148e0  , 4.266e-2 , 9.370e0])
T1_vf96 = array([7.036e5  , 4.677e6  , 2.7674e6])
sqrt_T0_vf96 = sqrt(T0_vf96)
sqrt_T1_vf96 = sqrt(T1_vf96)

# Voronov collisional ionisation rate fit coefficients
dE_vor97 = array([13.6, 24.6, 54.4])
P_vor97 = array([0, 0, 1])
A_vor97 = array([0.291e-7, 0.175e-7, 0.205e-8])
X_vor97 = array([0.232, 0.180, 0.265])
K_vor97 = array([0.39, 0.35, 0.25])
  
# Scholz & Walters HI collisional and excitation cooling rate fit coefficients
d0_sw91 = array([2.137913e2, 2.7125446e2])
d1_sw91 = array([-1.139492e2, -9.8019455e1])
d2_sw91 = array([2.506062e1, 1.4007276e1])
d3_sw91 = array([-2.762755e0, -9.7808421e-1])
d4_sw91 = array([1.515352e-1, 3.3562891e-2])
d5_sw91 = array([-3.290382e-3, -4.5533231e-4])

#----------------------------------------

def sigma_photo(energy): # photionization cross section for HI, HeI, HeII in cm^2, energy is in eV
  # photoionization cross sections from D. A. Verner, G. J. Ferland, K. T. Korista, and D. G. Yakovlev, 1996, ApJ, 465, 487
  Eth = array([13.60,24.59,54.42]) * eV
  Emax = 5.0e4 * eV
  E_0 = array([0.4298,13.61,1.72]) * eV
  sigma_0 = array([5.475e4,9.492e2,1.369e4]) * 1.0e-18 # cm^2
  y_a = array([32.88,1.469,32.88])
  P = array([2.963,3.188,2.963])
  y_w = array([0.0,2.039,0.0])
  y_0 = array([0.0,0.4434,0.0])
  y_1 = array([0.0,2.136,0.0])
  Emax_thick = array([5000.0,5000.0,5000.0]) * eV
  
  x = energy * eV / E_0 - y_0
  y = sqrt(x**2 + y_1**2)
  
  sigma = sigma_0 * ((x-1.0)**2 + y_w**2) * y**(0.5*P-5.5) * (1.0+sqrt(y/y_a))**(-P)
  
  #sigma /= 1.0e4  # cm^2 -> m^2
  
  ind = where(energy * eV < Eth)[0]
  sigma[ind] = 0.0
  
  return sigma

#----------------------------------------

class cooler:

  def __init__(self, treecool_filename = "TREECOOL_HM2012", h = 0.704, omega_m = 0.272, omega_b = 0.0456, f=0.76):
    self.treecool_filename = treecool_filename
    self.treecool_dat = loadtxt(treecool_filename)
  
    self.h = h
    self.omega_m = omega_m
    self.omega_l = 1.0 - omega_m
    self.omega_b = omega_b
    
    self.hubble_0 = h * 100.0 * 1000.0 / (1.0e6 * pc)   # in s^-1
    
    self.f = f   # hydrogen mass fraction
    self.n_He_all = 0.25*(1.0-f)/f
    
    self.rhocrit = 2.77536627e11 * h**2 * msun / Mpc**3   # comoving, in SI
    self.nHcgs_comov_mean = self.rhocrit * omega_b * f / mproton_si * 1.0e-6   # comoving, in cgs at mean density


  def set_photo_rates_from_uvb(self, z):
    self.z_photo = z
    
    log10_1_plus_z = log10(1.0 + z)
    
    # --- used previously, inconsistent with Gadget ---
    #self.Gamma_H0 = interp(log10_1_plus_z, self.treecool_dat[:,0], self.treecool_dat[:,1], right=0.0) # in 1/s
    #self.Gamma_He0 = interp(log10_1_plus_z, self.treecool_dat[:,0], self.treecool_dat[:,2], right=0.0)
    #self.Gamma_Hep = interp(log10_1_plus_z, self.treecool_dat[:,0], self.treecool_dat[:,3], right=0.0)
    #self.eps_H0 = interp(log10_1_plus_z, self.treecool_dat[:,0], self.treecool_dat[:,4], right=0.0) # in erg/s
    #self.eps_He0 = interp(log10_1_plus_z, self.treecool_dat[:,0], self.treecool_dat[:,5], right=0.0)
    #self.eps_Hep = interp(log10_1_plus_z, self.treecool_dat[:,0], self.treecool_dat[:,6], right=0.0)
    # ---
  
    self.Gamma_H0 = 10.0**interp(log10_1_plus_z, self.treecool_dat[:,0], log10(self.treecool_dat[:,1]), right=-1000.0) # in 1/s
    self.Gamma_He0 = 10.0**interp(log10_1_plus_z, self.treecool_dat[:,0], log10(self.treecool_dat[:,2]), right=-1000.0)
    self.Gamma_Hep = 10.0**interp(log10_1_plus_z, self.treecool_dat[:,0], log10(self.treecool_dat[:,3]), right=-1000.0)
    self.eps_H0 = 10.0**interp(log10_1_plus_z, self.treecool_dat[:,0], log10(self.treecool_dat[:,4]), right=-1000.0) # in erg/s
    self.eps_He0 = 10.0**interp(log10_1_plus_z, self.treecool_dat[:,0], log10(self.treecool_dat[:,5]), right=-1000.0)
    self.eps_Hep = 10.0**interp(log10_1_plus_z, self.treecool_dat[:,0], log10(self.treecool_dat[:,6]), right=-1000.0)
    
  
  def set_photo_rates_manually(self, Gamma_H0, Gamma_He0, Gamma_Hep, eps_H0, eps_He0, eps_Hep, egy_unit="erg"):
    self.z_photo = -1
    
    self.Gamma_H0 = Gamma_H0
    self.Gamma_He0 = Gamma_He0
    self.Gamma_Hep = Gamma_Hep

    if egy_unit == "erg":
      self.eps_H0 = eps_H0
      self.eps_He0 = eps_He0
      self.eps_Hep = eps_Hep
    else:
      assert False

  
  def set_coefficients(self, temp, z):
    self.temp_coeff = temp
    self.z_coeff = z
    
    temp_eV = temp * kboltzmann_si / eV
    sqrt_temp = sqrt(temp)
    sqrt_temp_5 = sqrt_temp/sqrt(1.0e5)
    
    # in cm^3/s from Verner & Ferland, 1996, ApJS, 103, 467
    self.alpha_Hp = a_vf96[0]/(sqrt_temp/sqrt_T0_vf96[0]*pow(1.0+sqrt_temp/sqrt_T0_vf96[0],1.0-b_vf96[0])*pow(1.0+sqrt_temp/sqrt_T1_vf96[0],1.0+b_vf96[0]))
    self.alpha_Hep = a_vf96[1]/(sqrt_temp/sqrt_T0_vf96[1]*pow(1.0+sqrt_temp/sqrt_T0_vf96[1],1.0-b_vf96[1])*pow(1.0+sqrt_temp/sqrt_T1_vf96[1],1.0+b_vf96[1]))
    self.alpha_Hepp = a_vf96[2]/(sqrt_temp/sqrt_T0_vf96[2]*pow(1.0+sqrt_temp/sqrt_T0_vf96[2],1.0-b_vf96[2])*pow(1.0+sqrt_temp/sqrt_T1_vf96[2],1.0+b_vf96[2]))
  
    # in cm^3/s from Katz et. al. 1996, ApJS, 105,19; seems originally from Aldrovandi & Pequignot, 1973, A&A, 25, 137
    self.alpha_d = 1.9e-3 * temp**-1.5 * exp(-4.7e5/temp) * (1.0 + 0.3*exp(-0.94e5/temp))
    
    ## collissional ionization rates  from Katz et. al. 1996, ApJS, 105,19
    #self.Gamma_eH0 = 5.85e-11 * sqrt(temp) * exp(-157809.1/temp) / (1.0 + sqrt(temp/1.0e5))
    #self.Gamma_eHe0 = 2.38e-11 * sqrt(temp) * exp(-285335.4/temp) / (1.0 + sqrt(temp/1.0e5))
    #self.Gamma_eHep = 5.68e-12 * sqrt(temp) * exp(-631515.0/temp) / (1.0 + sqrt(temp/1.0e5))
  
    # Collisional ionisation rates [cm^3 s^-1] Voronov 1997, ADNDT, 65, 1
    self.Gamma_eH0 = 0.0
    self.Gamma_eHe0 = 0.0
    self.Gamma_eHep = 0.0
  
    if dE_vor97[0]/temp_eV < 70:
      self.Gamma_eH0 = A_vor97[0] * pow(dE_vor97[0]/temp_eV, K_vor97[0]) * exp(-dE_vor97[0]/temp_eV) * (1.0+P_vor97[0]*sqrt(dE_vor97[0]/temp_eV)) / (X_vor97[0] + dE_vor97[0]/temp_eV)      
    if dE_vor97[1]/temp_eV < 70:
      self.Gamma_eHe0 = A_vor97[1] * pow(dE_vor97[1]/temp_eV, K_vor97[1]) * exp(-dE_vor97[1]/temp_eV) * (1.0+P_vor97[1]*sqrt(dE_vor97[1]/temp_eV)) / (X_vor97[1] + dE_vor97[1]/temp_eV)        
    if dE_vor97[2]/temp_eV < 70:
      self.Gamma_eHep = A_vor97[2] * pow(dE_vor97[2]/temp_eV, K_vor97[2]) * exp(-dE_vor97[2]/temp_eV) * (1.0+P_vor97[2]*sqrt(dE_vor97[2]/temp_eV)) / (X_vor97[2] + dE_vor97[2]/temp_eV)
  
    # heating & cooling (all in cm^3 erg / s)
    self.Lambda_ff = 1.42e-27 * sqrt(temp) * (1.1 + 0.34 * exp(-(5.5 - log10(temp))**2 / 3.0)) # 1.43e-27 in Gadget
  
    # from Katz et. al. 1996, ApJS, 105,19
    self.Lambda_ce_H0 = 7.5e-19 * exp(-118348.0/temp) / (1 + sqrt_temp_5)
    self.Lambda_ce_He0 = 9.1e-27 * temp**-0.1687 * exp(-13179/temp) / (1 + sqrt_temp_5)
    self.Lambda_ce_Hep = 5.54e-17 * temp**-0.397 * exp(-473638.0/temp) / (1 + sqrt_temp_5)
  
    self.Lambda_ci_H0 = 1.27e-21 / 5.85e-11 * self.Gamma_eH0
    self.Lambda_ci_He0 = 9.38e-22 / 2.38e-11 * self.Gamma_eHe0
    self.Lambda_ci_Hep = 4.95e-22 / 5.68e-12 * self.Gamma_eHep
  
    self.Lambda_re_Hp = 8.7e-27 / 8.4e-11 * self.alpha_Hp*temp
    self.Lambda_re_Hep = 1.55e-26 / 1.5e-10 * self.alpha_Hep*temp
    self.Lambda_re_Hepp = 3.48e-26 / 3.36e-10 * self.alpha_Hepp*temp
  
    self.Lambda_re_d = 1.24e-13 / 1.9e-3 * self.alpha_d
  
    # Compton cooling off the CMB
    self.Lambda_compton = 5.65e-36 * (temp - 2.73 * (1.0 + z)) * (1.0 + z)**4 # in erg/s/cm^3, rate taken from Gadget code


  def find_eq_state_from_u(self, Delta, z, u, temp_guess=1.0e4, ne_guess=1.0): # u in (cm/s)^2
    a = 1.0 / (1.0 + z)
    hubble_z = self.hubble_0 * sqrt(self.omega_m / a**3 + self.omega_l)   # in s^-1
    
    nHcgs = self.nHcgs_comov_mean * (1.0 + z)**3 * Delta
    
    #self.set_photo_rates(z)
    
    temp = temp_guess
    ne_old = ne_guess
    n_e = ne_guess
    temp_old = -1.0
    
    nit = 0
    while (abs((temp - temp_old)/temp_old) > 1.0e-7):
      #print nit, temp, n_e
      
      n_e = 0.5 * (ne_old + n_e)
      
      self.set_coefficients(temp, z)
      
      # get ionization state
      if n_e == 0:
        n_H0 = 1.0
      else:
        n_H0 = self.alpha_Hp / (self.Gamma_H0/(n_e*nHcgs) + self.Gamma_eH0 + self.alpha_Hp) # used n_Hp = 1.0 - n_H0, corresponds to Eq. (33) in Katz+1996
      n_Hp = 1.0 - n_H0
      
      if n_e == 0 or self.Gamma_He0/(n_e*nHcgs) + self.Gamma_eHe0 == 0:
        n_He0 = self.n_He_all
        n_Hep = 0.0
        n_Hepp = 0.0
      else:
        n_Hep = self.alpha_Hepp*self.n_He_all / (self.Gamma_Hep/(n_e*nHcgs) + self.Gamma_eHep + self.alpha_Hepp + self.alpha_Hepp * (self.alpha_Hep + self.alpha_d) / (self.Gamma_He0/(n_e*nHcgs) + self.Gamma_eHe0))   # Eq. (35), obtained by solving for n_Hep the set of three equations: 2 rate equations + He number density conservation 
        n_He0 = (self.alpha_Hep + self.alpha_d)*n_Hep / (self.Gamma_He0/(n_e*nHcgs) + self.Gamma_eHe0)
        n_Hepp = n_Hep*(self.Gamma_Hep/(n_e*nHcgs) + self.Gamma_eHep) / self.alpha_Hepp
      
      ne_old = n_e
      temp_old = temp
      
      n_e = n_Hp + n_Hep + 2.0*n_Hepp
      
      # get new temperature
      mean_mw = 4.0 / (1.0 + 3.0*self.f + 4.0*self.f*n_e)   # in hydrogen atom masses
      temp = 2.0/3.0*u*mean_mw*mproton_cgs/kboltzmann_cgs   # in Kelvin
         
      #print temp_old, temp, n_H0, n_Hp, n_He0, n_Hep, n_Hepp, n_e, mean_mw
      
      nit += 1
      
    return temp, nHcgs, n_H0, n_Hp, n_He0, n_Hep, n_Hepp, n_e, mean_mw
 
 
  def find_eq_state_from_temp(self, Delta, z, temp, ne_guess=1.0): # u in (cm/s)^2
    a = 1.0 / (1.0 + z)
    hubble_z = self.hubble_0 * sqrt(self.omega_m / a**3 + self.omega_l)   # in s^-1
    
    nHcgs = self.nHcgs_comov_mean * (1.0 + z)**3 * Delta
    
    #self.set_photo_rates(z)
    
    n_e = ne_guess
    u = 1.0e10
    u_old = -1.0
    while (abs((u - u_old)/u_old) > 1.0e-7):
      self.set_coefficients(temp, z)
      
      # get ionization state
      if n_e == 0:
        n_H0 = 1.0
      else:
        n_H0 = self.alpha_Hp / (self.Gamma_H0/(n_e*nHcgs) + self.Gamma_eH0 + self.alpha_Hp) # used n_Hp = 1.0 - n_H0, corresponds to Eq. (33) in Katz+1996
      n_Hp = 1.0 - n_H0
      
      if n_e == 0 or self.Gamma_He0/(n_e*nHcgs) + self.Gamma_eHe0 == 0:
        n_He0 = self.n_He_all
        n_Hep = 0.0
        n_Hepp = 0.0
      else:
        n_Hep = self.alpha_Hepp*self.n_He_all / (self.Gamma_Hep/(n_e*nHcgs) + self.Gamma_eHep + self.alpha_Hepp + self.alpha_Hepp * (self.alpha_Hep + self.alpha_d) / (self.Gamma_He0/(n_e*nHcgs) + self.Gamma_eHe0))   # Eq. (35), obtained by solving for n_Hep the set of three equations: 2 rate equations + He number density conservation 
        n_He0 = (self.alpha_Hep + self.alpha_d)*n_Hep / (self.Gamma_He0/(n_e*nHcgs) + self.Gamma_eHe0)
        n_Hepp = n_Hep*(self.Gamma_Hep/(n_e*nHcgs) + self.Gamma_eHep) / self.alpha_Hepp
        
      n_e = n_Hp + n_Hep + 2.0*n_Hepp
      
      # get new temperature
      u_old = u
      
      mean_mw = 4.0 / (1.0 + 3.0*self.f + 4.0*self.f*n_e)   # in hydrogen atom masses
      u = 3.0/2.0*temp*kboltzmann_cgs/(mean_mw*mproton_cgs)   # in (cm/s)^2
     
      #print u_old, u, n_H0, n_Hp, n_He0, n_Hep, n_Hepp, n_e, mean_mw
      
    return u, nHcgs, n_H0, n_Hp, n_He0, n_Hep, n_Hepp, n_e, mean_mw

    
