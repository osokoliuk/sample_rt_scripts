import os, sys, inspect

# Find current path
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))

import Sherwood.Utilities.Readsnap.readsnap as rs
import numpy as np
from astropy import units as u
import time

class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

CURSOR_UP_ONE = '\x1b[1A'
ERASE_LINE = '\x1b[2K'

n_type_global = 11 # types of different data that can be read in (pos, poss, posh, M, Ms, Mh, U, rho, ne, nnh, hsml)

def print_elapsed_time(dt, process="Loading"):

    mins, secs = divmod(dt, 60)
    hours, mins = divmod(mins, 60)
    days, hours = divmod(hours, 24)

    if mins == 0 and hours == 0 and days == 0:
        print(process + " took {:.2f} s".format(secs))
    elif hours == 0 and days == 0:
        print(process + " took {:d}:{:02d}".format(int(mins), int(secs)))
    elif days == 0:
        print(process + " took {:d}:{:02d}:{:02d}".format(int(hours), int(mins), int(secs)))
    else:
        print(process + " took {:d} days, {:d}:{:02d}:{:02d}".format(int(days), int(hours), int(mins), int(secs)))
    print('\n')




def select_zoom_parts(positions, zoom, dzoom, boxsize):

    # Define region in x
    x_reg = ( positions[0] > 1e3*(zoom[0]-dzoom) ) * ( positions[0] < 1e3*(zoom[1]+dzoom) )

    # Account for boundary cases in x
    if 1e3*(zoom[0]-dzoom) < 0:
        x_reg += (positions[0] > (1e3*(zoom[0]-dzoom))%boxsize)
    if 1e3*(zoom[1]+dzoom) > boxsize:
        x_reg += (positions[0] < (1e3*(zoom[1]+dzoom))%boxsize)

    # Define region in y
    y_reg = ( positions[1] > 1e3*(zoom[2]-dzoom) ) * ( positions[1] < 1e3*(zoom[3]+dzoom) )

    # Account for boundary cases in y
    if 1e3*(zoom[2]-dzoom) < 0:
        y_reg += (positions[1] > (1e3*(zoom[2]-dzoom))%boxsize)
    if 1e3*(zoom[3]+dzoom) > boxsize:
        y_reg += (positions[1] < (1e3*(zoom[3]+dzoom))%boxsize)

    # Combine
    zoom_parts = x_reg * y_reg

    return zoom_parts





def load(size, res, phys, nr, Sherwood="S", check=False, zoom=None, nb=None, data=np.tile(True, n_type_global), dzoomTF=True, load_mass=False, verbose=True):

    """

    Function that loads data from a simulation snapshot (or multiple subsnapshots).

    Arguments:
    - size:      size of the simulation box in Mpc, e.g. 80 (string, int, or float)
    - res:       resolution of the simulation, e.g. 512 (string, int, or float)
    - phys:      toggle PS13 physics ("" or "_ps13")
    - nr:        snapshot number, e.g. 009 (string, int, or float)
    - Sherwood:  identification of Sherwood run: 'S' (original), "ReS" (ReSherwood), or "ReS2" (ReSherwood2), or "ssS" (self-shielding Sherwood)
    - check:     boolean controlling if data is actually loaded (False) or just metadata (True)
    - zoom:      when unequal to None, a list [xmin, xmax, ymin, ymax] of boundaries to zoom in on (in Mpc)
    - nb:        when unequal to None, a list [zmin, zmax] of boundaries to make a 'narrowband' of (in Mpc)
    - data:      list/array of data that has to be loaded, in the order of [pos, poss, posh, M, Ms, Mh, U, rho, ne, nnh, hsml]
                 (can also be int for the position (0-9) of the data that will be loaded, or a list of strings containing
                 the name of data types that will be loaded)
    - dzoomTF:   control whether parts outside the zoom region are also loaded
    - load_mass: if True, all masses (optional: within zoom/nb) will be loaded
    - verbose:   toggle terminal output

    Returns:

    Data (if check is False):
    - pos: an (N, 3) array of particle positions in h^-1 ckpc (comoving kpc)
    - poss: an (N, 3) array of stellar positions in h^-1 ckpc
    - posh: an (N, 3) array of halo positions in h^-1 ckpc
    - M: particle's baryonic mass in g
    - Ms: stellar mass in g
    - Mh: halo's mass in g
    - U: internal energy in 10^-3 km^2/s^2 = 10^3 m^2/s^2 = 10^3 J/kg = J/g
    - rho: (physical) baryon density in g/cm^3
    - ne: number of e- per H
    - nnh: number of neutral H (HI) per H
    - hsml: smoothing length in kpc for gas

    Metadata:
    - N_gas: total number of gas particles
    - N_s: total number of star particles
    - N_h: total number of (dark matter) halo particles
    - z: redshift
    - a: expansion factor
    - boxsize: length of the simulation cube (in comoving (!) kpc)
    - omega_m: fraction of matter (out of total energy)
    - omega_l: fraction of dark energy (out of total energy)
    - omega_b: fraction of barionic matter (out of matter)
    - omega_dm: fraction of dark matter (out of matter)
    - h: Hubble parameter
    - h_inv: inverse Hubble parameter
    - H0: Hubble constant at z=0 (in s^-1)
    - H: Hubble constant at z=z (in s^-1)
    - rho_crit0: physical (!) critical density of the Universe (if Omega=1), given by (3.0 * H0**2 / (8.0 * np.pi * G) at z=0 (in g/cm^3)
    - rho_meanb: physical (!) baryonic mean density of the Universe (if Omega=1), given by (3.0 * H(z)**2 / (8.0 * np.pi * G) at z=z (in g/cm^3)
    - f_H: fraction of hydrogen (out of baryonic matter)
    - f_He: fraction of helium (out of baryonic matter)


    --- Example usage ---

    # Simulation path:
    size = "80"
    res = "512"
    phys = "_ps13"

    # Read in simulation data: loop over snap files

    pos, poss, posh, M, Ms, Mh, U, rho, ne, nnh, hsml = ld.load(size, res, phys, nr)

    """

    if Sherwood == "S":
        root = "/data/curie3/PRACE_ra1865/"
    elif Sherwood == "ReS":
        root = "/data/emergence6/kulkarni/ReSherwood/"
    elif Sherwood == "ReS2":
        root = "/data/emergence7/kulkarni/ReSherwood/"
    elif Sherwood == "ssS":
        root = "/data/emergence4/puchwein/joris/"
    n_type = n_type_global # types of different data that can be read in (pos, posh, M, Ms, Mh, U, rho, ne, nnh, hsml)

    boxsize = float(size)*1e3 # in h^-1 ckpc

    data_names = ["pos", "poss", "posh", "M", "Ms", "Mh", "U", "rho", "ne", "nnh", "hsml"]
    data_rnames = ["gas particle positions", "star particle positions", "halo particle positions", "gas particle masses", "star particle masses", "halo particle masses", "internal gas particle energies", "gas particle densities", "gas particle electron fractions", "gas particle neutral hydrogen fractions", "gas particle smoothing lengths"]

    if check:
        data = np.tile(False, n_type)
    elif load_mass:
        data = np.tile(False, n_type)
        for j, x in enumerate(data_names):
            if x == "M" or x == "Ms":
                data[j] = True
    elif isinstance(data, int):
        data_nr = data
        data = np.tile(False, n_type)
        data[data_nr] = True
    elif len(data) != n_type:
        if isinstance(data[0], str):
            data_load = data
            data = np.tile(False, n_type)

            for i in data_load:
                for j, x in enumerate(data_names):
                    if x == i:
                        data[j] = True
        elif not (all(isinstance(x, bool) for x in data) or all(isinstance(x, np.bool_) for x in data)):
            raise SystemExit("Error: could not read in which data types to load.")

    if isinstance(size, int):
        size = str(size)
    if isinstance(size, float):
        size = "{:.0f}".format(size)

    if isinstance(res, int):
        res = str(res)
    if isinstance(res, float):
        res = "{:.0f}".format(res)

    if isinstance(nr, int):
        nr = "{:03d}".format(nr)
    if isinstance(nr, float):
        nr = "{:03.0f}".format(nr)

    if Sherwood == "S":
        key = size + '_' + res + phys
        sim = "planck1_" + key + '/'
    elif Sherwood == "ReS":
        if phys == "_ps13":
            raise SystemExit("Error: ReSherwood does not have PS13 runs.")
        key = 'L' + size + "_N" + res
        sim = key + '/'
    elif Sherwood == "ReS2":
        if phys == "_ps13":
            raise SystemExit("Error: ReSherwood does not have PS13 runs.")
        key = 'L' + size + "_N" + res + "_2"
        sim = key + '/'
    elif Sherwood == "ssS":
        if phys == "_ps13":
            raise SystemExit("Error: ssSherwood does not have PS13 runs.")
        key = size + '_' + res + phys
        sim = "planck1_" + key + "_self_shield/"

    snapshot = "snap_" + nr

    snapfile = root + sim + snapshot

    snapdir = "snapdir_" + nr + '/'



    # Checks

    if not ((os.path.isfile(snapfile + ".hdf5")) or (os.path.isfile(root + sim + snapdir + snapshot + ".hdf5")) or (os.path.isfile(root + sim + snapdir + snapshot + ".0.hdf5"))):
        raise SystemExit("Error: simulation " + sim[:-1] + ", snapshot " + nr +  " does not exist.")

    if zoom != None:
        if zoom[0] < 0:
            raise SystemExit("Error: invalid zoom argument given. The xmin (zoom[0] = " + str(zoom[0]) + ") should be larger than 0.")
        if zoom[1] > int(size):
            raise SystemExit("Error: invalid zoom argument given. The xmax (zoom[1] = " + str(zoom[1]) + ") should be smaller than the boxsize, " + size + " cMpc/h.")
        if zoom[2] < 0:
            raise SystemExit("Error: invalid zoom argument given. The ymin (zoom[2] = " + str(zoom[2]) + ") should be larger than 0.")
        if zoom[3] > int(size):
            raise SystemExit("Error: invalid zoom argument given. The ymax (zoom[3] = " + str(zoom[3]) + ") should be smaller than the boxsize, " + size + " cMpc/h.")

        if dzoomTF:
            if isinstance(dzoomTF, bool):
                dzoom = 2.0
            elif isinstance(dzoomTF, int):
                dzoom = float(dzoomTF)
            elif isinstance(dzoomTF, float):
                dzoom = dzoomTF
        else:
            dzoom = 0.0

    if nb != None:
        if nb[0] < -int(size):
            raise SystemExit("Error: invalid nb argument given. The zmin (nb[0] = " + str(nb[0]) + ") should be greater than minus the boxsize, " + -int(size) + " cMpc/h.")
        if nb[0] > int(size):
            raise SystemExit("Error: invalid nb argument given. The zmin (nb[0] = " + str(nb[0]) + ") should be smaller than the boxsize, " + size + " cMpc/h.")
        if nb[1] > int(size):
            raise SystemExit("Error: invalid nb argument given. The zmax (nb[1] = " + str(nb[1]) + ") should be smaller than the boxsize, " + size + " cMpc/h.")

    if check:
        if zoom != None:
            raise SystemExit("Error: check must be False if zoom is given.")
        if nb != None:
            raise SystemExit("Error: check must be False if nb is given.")



    if os.path.isfile(snapfile + ".hdf5"):
        snap = snapshot
        ss = snapfile
    else:
        snap = snapdir + snapshot
        ss = root + sim + snap

    if verbose:
        if check:
            print('\n', bcolors.OKBLUE+"Loading metadata from simulation:", sim + snap, bcolors.ENDC, '\n')
        else:
            print('\n', bcolors.OKBLUE+"Loading data from simulation:", sim + snap, bcolors.ENDC)
            print('\n', "Data types loaded:\n- " + '\n- '.join(data_rnames[i] + ' (' + data_names[i] + ')' for i, d in enumerate(data) if d))
            print()

        if zoom != None:
            print("Zoom selected:", zoom[0], "< x [h^-1 cMpc] <", zoom[1], "and", zoom[2], "< y [h^-1 cMpc] <", zoom[3])
            if dzoomTF:
                print("    (with an extra", dzoom, "h^-1 cMpc loaded for SPH kernel projection)")
        if nb != None:
            print("Narrowband selected:", nb[0], "< z [h^-1 cMpc] <", nb[1])
        if zoom != None or nb != None:
            print()

    t0 = time.time()

    possibilities = []

    if os.path.isfile(ss + ".hdf5"):
        possibilities.append("")
        n_pos = 1
    else:
        j = 0
        subsnap = ".{:d}".format(j)
        while os.path.isfile(ss + subsnap + ".hdf5"):
            possibilities.append(subsnap)

            # Go to next subsnap
            j += 1
            subsnap = ".{:d}".format(j)

        n_pos = len(possibilities)

    N_gas_total = 0
    N_s_total = 0
    N_h_total = 0

    if (zoom != None) or (nb != None):
        N_gas = 0
        if (data[1] or data[4]):
            N_s = 0
        if (data[2] or data[5]):
            N_h = 0

        N_dgas = 0
        if (data[1] or data[4]):
            N_ds = 0
        if (data[2] or data[5]):
            N_dh = 0



    for i, subsnap in enumerate(possibilities):

        header = rs.snapshot_header(ss + subsnap)

        N_gas_total += header.npart[0]
        N_s_total += header.npart[4]
        N_h_total += header.npart[1]



        # For gas particles
        if (data[0] or data[3] or data[6] or data[7] or data[8] or data[9] or data[10]):
            if data[0] or (zoom != None) or (nb != None):
                # Read in gas particle positions (h^-1 ckpc)
                posi = (rs.read_block(ss + subsnap, "{:4}".format("POS"), parttype=0)).astype(np.float64)
            elif not data[0]:
                posi = np.empty(header.npart[0])

            posi_temp = posi.transpose() # temporarily back to positions in shape (3, N)

            # Select zoom particles if applicable
            if zoom != None:
                zoom_parts = select_zoom_parts(posi_temp, zoom, dzoom, boxsize)

                test = False
                if test:
                    from matplotlib import pyplot as plt
                    plt.figure()
                    plt.scatter(posi_temp[0][np.where(zoom_parts)]/1e3, posi_temp[1][np.where(zoom_parts)]/1e3)
                    plt.axvline(zoom[0])
                    plt.axvline(zoom[1])
                    plt.axhline(zoom[2])
                    plt.axhline(zoom[3])
                    plt.axvline(zoom[0] - dzoom)
                    if 1e3*(zoom[0]-dzoom) < 0:
                        plt.axvline(1e-3*((1e3*(zoom[0]-dzoom))%boxsize))
                    plt.axvline(zoom[1] + dzoom)
                    if 1e3*(zoom[1]+dzoom) > boxsize:
                        plt.axvline(1e-3*((1e3*(zoom[1]+dzoom))%boxsize))
                    plt.axhline(zoom[2] - dzoom)
                    if 1e3*(zoom[2]-dzoom) < 0:
                        plt.axhline(1e-3*((1e3*(zoom[2]-dzoom))%boxsize))
                    plt.axhline(zoom[3] + dzoom)
                    if 1e3*(zoom[3]+dzoom) > boxsize:
                        plt.axhline(1e-3*((1e3*(zoom[3]+dzoom))%boxsize))
                    plt.xlim(-0.1*boxsize/1e3, 1.1*boxsize/1e3)
                    plt.ylim(-0.1*boxsize/1e3, 1.1*boxsize/1e3)
                    plt.show()
            else:
                zoom_parts = np.tile(True, header.npart[0])

            # Select narrowband particles if applicable
            if nb != None:
                if nb[0] < 0:
                    nb_parts = (posi_temp[2] > (1e3*nb[0]%boxsize)) + (posi_temp[2] < (1e3*nb[1]%boxsize))
                else:
                    nb_parts = (posi_temp[2] > (1e3*nb[0]%boxsize)) * (posi_temp[2] < (1e3*nb[1]%boxsize))
            else:
                nb_parts = np.tile(True, header.npart[0])

            select = np.where(zoom_parts * nb_parts)
            posi = posi[select]

            if (zoom != None) or (nb != None):
                N_dgas += len(select[0]) # update number of gas particles loaded

                # Update number of particles actually in region
                if nb == None:
                    N_gas += np.sum((posi_temp[0] > (1e3*zoom[0])) * (posi_temp[0] < (1e3*zoom[1])) * (posi_temp[1] > (1e3*zoom[2])) * (posi_temp[1] < (1e3*zoom[3])))
                elif zoom != None:
                    N_gas += np.sum((posi_temp[0] > (1e3*zoom[0])) * (posi_temp[0] < (1e3*zoom[1])) * (posi_temp[1] > (1e3*zoom[2])) * (posi_temp[1] < (1e3*zoom[3])) * (posi_temp[2] > (1e3*nb[0])) * (posi_temp[2] < (1e3*nb[1])))
                else:
                    N_gas += np.sum(nb_parts)

                del posi_temp



        # For star particles
        if (data[1] or data[4]):
            if data[1] or (zoom != None) or (nb != None):
                # Read in star particle positions (h^-1 ckpc)
                possi = (rs.read_block(ss + subsnap, "{:4}".format("POS"), parttype=4)).astype(np.float64)
            elif not data[1]:
                possi = np.empty(header.npart[4])

            possi_temp = possi.transpose() # temporarily back to positions in shape (3, N)

            # Select zoom particles if applicable
            if zoom != None:
                zoom_sparts = select_zoom_parts(possi_temp, zoom, dzoom, boxsize)
            else:
                zoom_sparts = np.tile(True, header.npart[4])

            # Select narrowband particles if applicable
            if nb != None:
                if nb[0] < 0:
                    nb_sparts = (possi_temp[2] > (1e3*nb[0]%boxsize)) + (possi_temp[2] < (1e3*nb[1]%boxsize))
                else:
                    nb_sparts = (possi_temp[2] > (1e3*nb[0]%boxsize)) * (possi_temp[2] < (1e3*nb[1]%boxsize))
            else:
                nb_sparts = np.tile(True, header.npart[4])

            selects = np.where(zoom_sparts * nb_sparts)
            possi = possi[selects]

            if (zoom != None) or (nb != None):
                N_ds += len(selects[0]) # update number of gas particles loaded

                # Update number of particles actually in region
                if nb == None:
                    N_s += np.sum((possi_temp[0] > (1e3*zoom[0])) * (possi_temp[0] < (1e3*zoom[1])) * (possi_temp[1] > (1e3*zoom[2])) * (possi_temp[1] < (1e3*zoom[3])))
                elif zoom != None:
                    N_s += np.sum((possi_temp[0] > (1e3*zoom[0])) * (possi_temp[0] < (1e3*zoom[1])) * (possi_temp[1] > (1e3*zoom[2])) * (possi_temp[1] < (1e3*zoom[3])) * (possi_temp[2] > (1e3*nb[0])) * (possi_temp[2] < (1e3*nb[1])))
                else:
                    N_s += np.sum(nb_sparts)

                del possi_temp



        # For halo particles
        if (data[2] or data[5]):
            if data[2] or (zoom != None) or (nb != None):
                # Read in halo particle positions (h^-1 ckpc)
                poshi = (rs.read_block(ss + subsnap, "{:4}".format("POS"), parttype=1)).astype(np.float64)
            elif not data[1]:
                poshi = np.empty(header.npart[1])

            poshi_temp = poshi.transpose() # temporarily back to positions in shape (3, N)

            # Select zoom particles if applicable
            if zoom != None:
                zoom_hparts = select_zoom_parts(poshi_temp, zoom, dzoom, boxsize)
            else:
                zoom_hparts = np.tile(True, header.npart[1])

            # Select narrowband particles if applicable
            if nb != None:
                if nb[0] < 0:
                    nb_hparts = (poshi_temp[2] > (1e3*nb[0]%boxsize)) + (poshi_temp[2] < (1e3*nb[1]%boxsize))
                else:
                    nb_hparts = (poshi_temp[2] > (1e3*nb[0]%boxsize)) * (poshi_temp[2] < (1e3*nb[1]%boxsize))
            else:
                nb_hparts = np.tile(True, header.npart[1])

            selecth = np.where(zoom_hparts * nb_hparts)
            poshi = poshi[selecth]

            if (zoom != None) or (nb != None):
                N_dh += len(selecth[0]) # update number of gas particles loaded

                # Update number of particles actually in region
                if nb == None:
                    N_h += np.sum((poshi_temp[0] > (1e3*zoom[0])) * (poshi_temp[0] < (1e3*zoom[1])) * (poshi_temp[1] > (1e3*zoom[2])) * (poshi_temp[1] < (1e3*zoom[3])))
                elif zoom != None:
                    N_h += np.sum((poshi_temp[0] > (1e3*zoom[0])) * (poshi_temp[0] < (1e3*zoom[1])) * (poshi_temp[1] > (1e3*zoom[2])) * (poshi_temp[1] < (1e3*zoom[3])) * (poshi_temp[2] > (1e3*nb[0])) * (poshi_temp[2] < (1e3*nb[1])))
                else:
                    N_h += np.sum(nb_hparts)

                del poshi_temp



        if data[0]:
            if (zoom == None) and (nb == None):
                posi = (rs.read_block(ss + subsnap, "{:4}".format("POS"), parttype=0)).astype(np.float64)[select]
        else:
            posi = np.array([])

        if data[1]:
            if (zoom == None) and (nb == None):
                possi = (rs.read_block(ss + subsnap, "{:4}".format("POS"), parttype=4)).astype(np.float64)[selects]
        else:
            possi = np.array([])

        if data[2]:
            if (zoom == None) and (nb == None):
                poshi = (rs.read_block(ss + subsnap, "{:4}".format("POS"), parttype=1)).astype(np.float64)[selecth]
        else:
            poshi = np.array([])

        if data[3]:
            Mi = (rs.read_block(ss + subsnap, "{:4}".format("MASS"), parttype=0)).astype(np.float64)[select]
        else:
            Mi = np.array([])

        if data[4]:
            Msi = (rs.read_block(ss + subsnap, "{:4}".format("MASS"), parttype=4)).astype(np.float64)[selects]
        else:
            Msi = np.array([])

        if data[5]:
            Mhi = (rs.read_block(ss + subsnap, "{:4}".format("MASS"), parttype=1)).astype(np.float64)[selecth]
        else:
            Mhi = np.array([])

        if data[6]:
            Ui = (rs.read_block(ss + subsnap, "{:4}".format("U"), parttype=0)).astype(np.float64)[select]
        else:
            Ui = np.array([])

        if data[7]:
            rhoi = (rs.read_block(ss + subsnap, "{:4}".format("RHO"), parttype=0)).astype(np.float64)[select]
        else:
            rhoi = np.array([])

        if data[8]:
            nei = (rs.read_block(ss + subsnap, "{:4}".format("NE"), parttype=0)).astype(np.float64)[select]
        else:
            nei = np.array([])

        if data[9]:
            nnhi = (rs.read_block(ss + subsnap, "{:4}".format("NH"), parttype=0)).astype(np.float64)[select]
        else:
            nnhi = np.array([])

        if data[10]:
            hsmli = (rs.read_block(ss + subsnap, "{:4}".format("HSML"), parttype=0)).astype(np.float64)[select]
        else:
            hsmli = np.array([])



        if i == 0:
            #print header.__dict__

            z = header.redshift.astype(np.float64)
            a = (1.0/(1.0 + z)).astype(np.float64)

            if verbose:
                print("Snapshot", nr, "parameters:")
                print("Redshift:                            ", z)

            omega_m = header.omega_m.astype(np.float64)
            omega_l = header.omega_l.astype(np.float64)
            omega_b = (0.0482 * z/z).astype(np.float64) # at redshift 0!
            omega_dm = (omega_m - omega_b).astype(np.float64)

            h = header.hubble.astype(np.float64)
            h_inv = (1.0/h).astype(np.float64)
            H0 = ((h * 100.0)/3.08567758147e+19).astype(np.float64) # from km/s/Mpc to s^-1
            H = (H0 * np.sqrt(omega_m/a**3 + omega_l)) # in s^-1
            
            # At redshift z=0
            rho_crit0 = (3.0 * H0**2 / (8.0 * np.pi * 6.67408e-8)).astype(np.float64) # in g/cm^3 (G in cm^3/g/s^2)
            # rho_mean0 = (rho_crit0 / a**3).astype(np.float64) # (physical) mean density, scaled back to redshift
            rho_crit0b = (rho_crit0 * omega_b).astype(np.float64)
            rho_mean0b = (rho_crit0b / a**3).astype(np.float64) # (physical) mean baryonic density, scaled back to redshift
            #print rho_crit0, rho_mean0, rho_crit0b, rho_mean0b

            '''# At redshift z
            rho_crit = (3.0 * H**2 / (8.0 * np.pi * 6.67408e-8)).astype(np.float64) # in g/cm^3 (G in cm^3/g/s^2)
            rho_mean = (rho_crit / a**3).astype(np.float64) # (physical) mean density, scaled back to redshift
            rho_critb = (rho_crit * omega_b).astype(np.float64)
            rho_meanb = (rho_critb / a**3).astype(np.float64) # (physical) mean baryonic density, scaled back to redshift
            print rho_crit, rho_mean, rho_critb, rho_meanb'''

            f_H = (0.76 * z/z).astype(np.float64) # fraction of baryons that are H
            f_He = (0.24 * z/z).astype(np.float64) # fraction of baryons that are He

            if verbose:
                print("Hubble constant:                     ", H0 * 3.08567758147e+19, "km/s/Mpc (at z=0)")
                print("Hubble constant:                     ", H * 3.08567758147e+19, "km/s/Mpc (at z={:.2f})".format(z))
                print("Physical critical density:           ", rho_crit0, "g/cm^3 (at z=0)")
                print("Physical mean baryon density:        ", rho_mean0b, "g/cm^3 (at z={:.2f})\n".format(z))

            pos = posi # (N, 3) array
            poss = possi # (N, 3) array
            posh = poshi # (N, 3) array
            M = Mi
            Ms = Msi
            Mh = Mhi
            U = Ui
            rho = rhoi
            ne = nei
            nnh = nnhi
            hsml = hsmli
        else:
            pos = np.append(pos, posi, axis=0) # (N, 3) array
            poss = np.append(poss, possi, axis=0) # (N, 3) array
            posh = np.append(posh, poshi, axis=0) # (N, 3) array
            M = np.append(M, Mi)
            Ms = np.append(Ms, Msi)
            Mh = np.append(Mh, Mhi)
            U = np.append(U, Ui)
            rho = np.append(rho, rhoi)
            ne = np.append(ne, nei)
            nnh = np.append(nnh, nnhi)
            hsml = np.append(hsml, hsmli)

        del posi, possi, poshi, Mi, Msi, Mhi, Ui, rhoi, nei, nnhi, hsmli

        if n_pos != 1:
            if verbose:
                if i==0:
                    print("Loaded", i, "out of", n_pos, "snapshot parts... 0.0%" + CURSOR_UP_ONE)
                else:
                    print(ERASE_LINE + CURSOR_UP_ONE + CURSOR_UP_ONE)

                if i+1 != n_pos:
                    print(ERASE_LINE + "Loaded", i+1, "out of", n_pos, "snapshot parts... {:.1f}%".format(100.0*(i+1)/float(n_pos)))
                else:
                    print(ERASE_LINE + "Loaded", i+1, "out of", n_pos, "snapshot parts!\n")

    if verbose:
        print("Total number of gas particles:       ", N_gas_total)
        if (zoom != None) or (nb != None):
            print("    (of which", N_dgas, "loaded for region,", N_gas, "contained in region)")

        if (data[1] or data[4]):
            print("Total number of stellar particles:   ", N_s_total)
            if (zoom != None) or (nb != None):
                print("    (of which", N_ds, "loaded for region,", N_s, "contained in region)")

        if (data[2] or data[5]):
            print("Total number of halo particles:      ", N_h_total)
            if (zoom != None) or (nb != None):
                print("    (of which", N_dh, "loaded for region,", N_h, "contained in region)")



    # Correct units of data

    unitM = h_inv * 1e10 * 1.98847541534e+33 # (conversion from 10^10 h^-1 M_sun) in g
    unitL = a * h_inv * 3.08567758147e+21 # (conversion from h^-1 ckpc) in cm

    #pos = pos # in h^-1 ckpc (comoving kpc)
    #poss = poss # in h^-1 ckpc
    #posh = posh # in h^-1 ckpc
    M *= unitM # particle's baryonic mass in g
    Ms *= unitM # stellar mass in g
    Mh *= unitM # halo's mass in g
    U *= 1e3 # in 10^-3 km^2/s^2 = 10^3 m^2/s^2 = 10^3 J/kg = J/g
    rho *= unitM / unitL**3 # (physical) gas density in g/cm^3
    #ne = ne # number of e- per H
    #nnh = nnh # number of neutral H (HI) per H
    #hsml = hsml # in h^-1 ckpc

    if verbose:
        if check:
            print('\n', bcolors.OKGREEN + "Finished loading metadata!" + bcolors.ENDC)
        else:
            print('\n', bcolors.OKGREEN + "Finished loading data!" + bcolors.ENDC)

    t1 = time.time()
    if verbose:
        print_elapsed_time(t1-t0)

    if check:
        return N_gas_total, N_h_total, N_s_total, z, a, boxsize, omega_m, omega_l, omega_b, omega_dm, h, h_inv, H0, H, rho_crit0, rho_mean0b, f_H, f_He
    else:
        return pos, poss, posh, M, Ms, Mh, U, rho, ne, nnh, hsml




################################################################################






















################################################################################

# Old zoom/nb code


"""
    # Zoom in on a certain area if wanted

    if zoom != None:
        if check:
            raise SystemExit("Error: check must be False.")

        if (data[3] or data[6] or data[7] or data[8] or data[9] or data[10]) and not data[0]:
            raise SystemExit("Error: gas positions must be loaded for zoom.")
        elif data[0]:
            pos_temp = pos.transpose() # temporarily back to positions in shape (3, N) (still h^-1 ckpc)
            #if verbose:print pos.shape, pos_temp.shape
            #print zoom
            dzoom = boxsize/20.0

            zoom_reg = np.where(np.logical_and(np.logical_and(pos_temp[0] > (1e3*zoom[0] - dzoom), pos_temp[0] < (1e3*zoom[1] + dzoom)), np.logical_and(pos_temp[1] > (1e3*zoom[2] - dzoom), pos_temp[1] < (1e3*zoom[3] + dzoom))))
            #if verbose:print zoom_reg

            if verbose:
                print '\n', len(zoom_reg[0]), "out of", N_gas, "particles selected in zoom"
                print len(np.where(np.logical_and(np.logical_and(pos_temp[0] > (1e3*zoom[0]), pos_temp[0] < (1e3*zoom[1])), np.logical_and(pos_temp[1] > (1e3*zoom[2]), pos_temp[1] < (1e3*zoom[3]))))[0]), "out of", N_gas, "particles contained in zoomed region", '\n'
            N_gas = len(zoom_reg[0]) # update number of gas particles
            del pos_temp

            pos = pos[zoom_reg]

            if data[3]:
                M = M[zoom_reg]
            if data[6]:
                U = U[zoom_reg]
            if data[7]:
                rho = rho[zoom_reg]
            if data[8]:
                ne = ne[zoom_reg]
            if data[9]:
                nnh = nnh[zoom_reg]
            if data[10]:
                hsml = hsml[zoom_reg]

        if data[4] and not data[1]:
            raise SystemExit("Error: star positions must be loaded for zoom.")
        elif data[1]:
            pos_temp = poss.transpose() # temporarily back to positions in shape (3, N) (still h^-1 ckpc)

            dzoom = boxsize/20.0

            zoom_reg = np.where(np.logical_and(np.logical_and(pos_temp[0] > (1e3*zoom[0] - dzoom), pos_temp[0] < (1e3*zoom[1] + dzoom)), np.logical_and(pos_temp[1] > (1e3*zoom[2] - dzoom), pos_temp[1] < (1e3*zoom[3] + dzoom))))

            if verbose:
                print '\n', len(zoom_reg[0]), "out of", N_s, "star particles selected in zoom"
                print len(np.where(np.logical_and(np.logical_and(pos_temp[0] > (1e3*zoom[0]), pos_temp[0] < (1e3*zoom[1])), np.logical_and(pos_temp[1] > (1e3*zoom[2]), pos_temp[1] < (1e3*zoom[3]))))[0]), "out of", N_s, "star particles contained in zoomed region", '\n'
            N_s = len(zoom_reg[0]) # update number of star particles
            del pos_temp

            poss = poss[zoom_reg]

            if data[4]:
                Ms = Ms[zoom_reg]

        if data[5] and not data[2]:
            raise SystemExit("Error: halo positions must be loaded for zoom.")
        elif data[2]:
            pos_temp = posh.transpose() # temporarily back to positions in shape (3, N) (still h^-1 ckpc)

            dzoom = boxsize/20.0

            zoom_reg = np.where(np.logical_and(np.logical_and(pos_temp[0] > (1e3*zoom[0] - dzoom), pos_temp[0] < (1e3*zoom[1] + dzoom)), np.logical_and(pos_temp[1] > (1e3*zoom[2] - dzoom), pos_temp[1] < (1e3*zoom[3] + dzoom))))

            if verbose:
                print '\n', len(zoom_reg[0]), "out of", N_h, "halo particles selected in zoom"
                print len(np.where(np.logical_and(np.logical_and(pos_temp[0] > (1e3*zoom[0]), pos_temp[0] < (1e3*zoom[1])), np.logical_and(pos_temp[1] > (1e3*zoom[2]), pos_temp[1] < (1e3*zoom[3]))))[0]), "out of", N_h, "halo particles contained in zoomed region", '\n'

            N_h = len(zoom_reg[0]) # update number of halo particles
            del pos_temp

            posh = posh[zoom_reg]

            if data[5]:
                Mh = Mh[zoom_reg]

    # Create a 'narrowband' selection

    if nb != None:
        if check:
            raise SystemExit("Error: check must be False.")

        if (data[3] or data[6] or data[7] or data[8] or data[9] or data[10]) and not data[0]:
            raise SystemExit("Error: gas positions must be loaded for nb.")
        elif data[0]:
            pos_temp = pos.transpose() # temporarily back to positions in shape (3, N) (still h^-1 ckpc)
            #if verbose:print pos.shape, pos_temp.shape

            dnb = 0.0
            #dnb = boxsize/20.0 # would alter projected maps

            zoom_reg = np.where(np.logical_and(pos_temp[2] > (1e3*nb[0] - dnb), pos_temp[2] < (1e3*nb[1] + dnb)))
            if verbose:
                #print zoom_reg
                print '\n', len(zoom_reg[0]), "out of", N_gas, "particles selected in nb"

                if zoom == None:
                    print len(np.where(np.logical_and(pos_temp[2] > (1e3*nb[0]), pos_temp[2] < (1e3*nb[1])))[0]), "out of", N_gas, "particles contained in nb region", '\n'
                else:
                    print len(np.where(np.logical_and(np.logical_and(pos_temp[2] > (1e3*nb[0]), pos_temp[2] < (1e3*nb[1])), np.logical_and(np.logical_and(pos_temp[0] > (1e3*zoom[0]), pos_temp[0] < (1e3*zoom[1])), np.logical_and(pos_temp[1] > (1e3*zoom[2]), pos_temp[1] < (1e3*zoom[3])))))[0]), "out of", N_gas, "particles contained in nb region", '\n'

            N_gas = len(zoom_reg[0]) # update number of gas particles
            del pos_temp

            pos = pos[zoom_reg]

            if data[3]:
                M = M[zoom_reg]
            if data[6]:
                U = U[zoom_reg]
            if data[7]:
                rho = rho[zoom_reg]
            if data[8]:
                ne = ne[zoom_reg]
            if data[9]:
                nnh = nnh[zoom_reg]
            if data[10]:
                hsml = hsml[zoom_reg]

        if data[4] and not data[1]:
            raise SystemExit("Error: star positions must be loaded for zoom.")
        elif data[1]:
            pos_temp = poss.transpose() # temporarily back to positions in shape (3, N) (still h^-1 ckpc)

            dnb = 0.0

            zoom_reg = np.where(np.logical_and(pos_temp[2] > (1e3*nb[0] - dnb), pos_temp[2] < (1e3*nb[1] + dnb)))

            if verbose:
                print '\n', len(zoom_reg[0]), "out of", N_s, "star particles selected in nb"

                if zoom == None:
                    print len(np.where(np.logical_and(pos_temp[2] > (1e3*nb[0]), pos_temp[2] < (1e3*nb[1])))[0]), "out of", N_s, "star particles contained in nb region", '\n'
                else:
                    print len(np.where(np.logical_and(np.logical_and(pos_temp[2] > (1e3*nb[0]), pos_temp[2] < (1e3*nb[1])), np.logical_and(np.logical_and(pos_temp[0] > (1e3*zoom[0]), pos_temp[0] < (1e3*zoom[1])), np.logical_and(pos_temp[1] > (1e3*zoom[2]), pos_temp[1] < (1e3*zoom[3])))))[0]), "out of", N_s, "star particles contained in nb region", '\n'

            N_s = len(zoom_reg[0]) # update number of star particles
            del pos_temp

            poss = poss[zoom_reg]

            if data[4]:
                Ms = Ms[zoom_reg]

        if data[5] and not data[2]:
            raise SystemExit("Error: halo positions must be loaded for nb.")
        elif data[2]:
            pos_temp = posh.transpose() # temporarily back to positions in shape (3, N) (still h^-1 ckpc)

            dnb = 0.0

            zoom_reg = np.where(np.logical_and(pos_temp[2] > (1e3*nb[0] - dnb), pos_temp[2] < (1e3*nb[1] + dnb)))

            if verbose:
                print '\n', len(zoom_reg[0]), "out of", N_h, "halo particles selected in nb"

                if zoom == None:
                    print len(np.where(np.logical_and(pos_temp[2] > (1e3*nb[0]), pos_temp[2] < (1e3*nb[1])))[0]), "out of", N_h, "halo particles contained in nb region", '\n'
                else:
                    print len(np.where(np.logical_and(np.logical_and(pos_temp[2] > (1e3*nb[0]), pos_temp[2] < (1e3*nb[1])), np.logical_and(np.logical_and(pos_temp[0] > (1e3*zoom[0]), pos_temp[0] < (1e3*zoom[1])), np.logical_and(pos_temp[1] > (1e3*zoom[2]), pos_temp[1] < (1e3*zoom[3])))))[0]), "out of", N_h, "halo particles contained in nb region", '\n'

            N_h = len(zoom_reg[0]) # update number of star particles
            del pos_temp

            posh = posh[zoom_reg]

            if data[5]:
                Mh = Mh[zoom_reg]
"""
