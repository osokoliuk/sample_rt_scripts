import numpy as np
from astropy.io import fits




class F:
    
    def __init__(self, filename, verbose=True):
        
        self.filename = filename
        self.verbose = verbose
    
    def __enter__(self):
        
        class FITS:
            
            """
            
            Class for reading in FITS files
            
            """
            
            def __init__(self, filename, verbose=True):
                
                self.filename = filename
                self.verbose = verbose
                
                # Read in FITS file of HDFS
                
                self.HDU_list = fits.open(self.filename)
                if self.verbose:
                    print('\n', "Data cube:", '\n')
                    self.HDU_list.info()
                
                header = self.HDU_list[0].header
                #print header
            
            
            
            def read_data(self):
            
                self.cube_data = self.HDU_list[1].data # in 10^-20 erg/s/cm^2/Angstrom
                self.cube_var = self.HDU_list[2].data # variance!

                return self.cube_data, self.cube_var
            
            
            
            def get_wl(self):
                
                header = self.HDU_list[1].header
                #print header
                
                CRVAL = header["CRVAL3"]
                CRPIX = header["CRPIX3"]
                CDELT = header["CDELT3"]
                CUNIT = header["CUNIT3"]
                CTYPE = header["CTYPE3"]
                assert CTYPE == "LINEAR" and CUNIT == "Angstrom"
                
                #print CRVAL, CRPIX, CDELT
                size = self.cube_data.shape[0]
                MUSE_w = np.arange(CRVAL, CRVAL + size * CDELT, CDELT) - (CRPIX-1) * np.tile(CDELT, size)
                MUSE_w *= 0.1 # convert to nm
                #print MUSE_w
                
                return MUSE_w
            
            
            
            def close(self):
                
                self.HDU_list.close()
        
        
        
        self.FITS_obj = FITS(self.filename, verbose=self.verbose)
        
        return self.FITS_obj
        
        
        
    def __exit__(self, exc_type, exc_value, traceback):
        
        self.FITS_obj.close()
        
        
