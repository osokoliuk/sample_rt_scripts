import numpy as np

pltfol = "../Plots/"

def alpha_A_HII_Draine2011(T):
    """Case A H II recombination coefficient.
    
    Draine equation 14.5

    """

    return 4.13e-13*(T/1.0e4)**(-0.7131-0.0115*np.log(T/1.0e4)) # cm^3 s^-1



def alpha_B_HII_Draine2011(T):
    """Case B H II recombination coefficient.
    
    Draine equation 14.6

    """

    return 2.54e-13*(T/1.0e4)**(-0.8163-0.0208*np.log(T/1.0e4)) # cm^3 s^-1



def alpha_A_HII_HuiGnedin1997(T):
    """Case A H II recombination coefficient.
    
    Hui and Gnedin 1997 (MNRAS 292 27; Appendix A).

    """

    t_HI = 1.57807e5 # K; H ionization threshold 
    reclambda = 2.0*t_HI/T
    
    return (1.269e-13 * (reclambda**1.503) /
            (1.0 + (reclambda/0.522)**0.470)**1.923) # cm^3 s^-1



def alpha_B_HII_HuiGnedin1997(T):
    """Case B H II recombination coefficient.
    
    Hui and Gnedin 1997 (MNRAS 292 27; Appendix A).

    """

    t_HI = 1.57807e5 # K; H ionization threshold 
    reclambda = 2.0*t_HI/T
    
    return (2.753e-14 * (reclambda**1.5) /
            (1.0 + (reclambda/2.74)**0.407)**2.242) # cm^3 s^-1



def alpha_A_HII_FukugitaKawasaki1994(T):
    """Case A H II recombination coefficient.
    
    Fukugita & Kawasaki (1994).

    """

    return 6.28e-11 * T**(-0.5) * (T/1e3)**(-0.2) / (1.0 + (T/1e5)**(0.7)) # cm^3 s^-1



def f_recA(T):
    """Probability of emission of a Ly-a photon per recombination.
    
    Dijkstra 2014

    """

    
    T4 = T/1.0e4
    return 0.41 - 0.165 * np.log10(T4) - 0.015 * (T4)**(-0.44)

def f_recB(T):
    """Probability of emission of a Ly-a photon per recombination.
    
    Dijkstra 2014, taken from Cantalupo et al. (2008)

    """

    
    T4 = T/1.0e4
    return 0.686 - 0.106 * np.log10(T4) - 0.009 * (T4)**(-0.44)

def eps_recLya(n_e, n_HII, T, alpha="Draine", f='B'):
    """ A function calculating the luminosity density of Lya due to recombination
    n_e, n_HII should be given in cm^-3, T in K
    apu: turn on astropy units or not
    
    """
    
    if f == 'A':
        f_rec = f_recA(T)
    
        # Both are returned as cm^3/s
        if alpha == "Draine":
            a = alpha_A_HII_Draine2011(T)
        elif alpha == "Hui":
            a = alpha_A_HII_HuiGnedin1997(T)
        elif alpha == "Fukugita":
            a = alpha_A_HII_FukugitaKawasaki1994(T)
        else:
            a = alpha
            #print a/alpha_A_HII_Draine2011(T)
    if f == 'B':
        f_rec = f_recB(T)
    
        # Both are returned as cm^3/s
        if alpha == "Draine":
            a = alpha_B_HII_Draine2011(T)
        elif alpha == "Hui":
            a = alpha_B_HII_HuiGnedin1997(T)
        else:
            a = alpha
            #print a/alpha_B_HII_Draine2011(T)
    
    return f_rec * n_e * n_HII * a * 1.63403376259e-11 # in erg/s/cm^3; E_Lya = 1.63403376259e-11 erg
    
#E_Lya = (10.2 * u.eV).to(u.erg).value
#E_Lya = 1e7 * h.value*c.value/(1.21567e-7)
#print E_Lya
