import numpy as np

def Omega_1s2p(T):
    """ A function that computes the collissional strength
    
    Scholz & Walters (1991), ApJ 380 (302)
    
    """
    
    I1 = np.where(np.logical_and(T>=2e3, T<6e4))
    I2 = np.where(np.logical_and(T>=6e4, T<6e6))
    I3 = np.where(np.logical_and(T>=6e6, T<=1e8))
    
    err = np.sum(T > 1e8)
    if err > 0:
        print("Minimal temperature:", np.min(T), 'K')
        print("Maximal temperature:", np.max(T), 'K')
        print("There are", err, "values of T > 1e8 K", '\n')
    
    if type(T) == type(np.array([])):
        shape = T.shape
    elif isinstance(T, int):
        T = float(T)
        shape = (1,)
    elif isinstance(T, float):
        shape = (1,)
    else:
        print("T is of type:")
        print(type(T))
        raise SystemExit("Error: T is not an array, int, or float.")
    
    empty_val = np.nan
    
    c0 = np.tile(empty_val, shape)
    c1 = np.tile(empty_val, shape)
    c2 = np.tile(empty_val, shape)
    c3 = np.tile(empty_val, shape)
    c4 = np.tile(empty_val, shape)
    c5 = np.tile(empty_val, shape)
    
    c0[I1] = -1.630155e2
    c1[I1] = 8.795711e1
    c2[I1] = -2.057117e1
    c3[I1] = 2.359573
    c4[I1] = -1.339059e-1
    c5[I1] = 3.021507e-3
    
    c0[I2] = 5.279996e2
    c1[I2] = -1.939399e2
    c2[I2] = 2.718982e1
    c3[I2] = -1.883399
    c4[I2] = 6.462462e-2
    c5[I2] = -8.811076e-4
    
    c0[I3] = -2.8133632e3
    c1[I3] = 8.1509685e2
    c2[I3] = -9.4418414e1
    c3[I3] = 5.4280565
    c4[I3] = -1.5467120e-1
    c5[I3] = 1.7439112e-3
    
    y = np.log(T)
    O = np.exp(c0 + c1 * y + c2 * y**2 + c3 * y**3 + c4 * y**4 + c5 * y**5)

    return O

def eps_excLya(n_e, n_HI, T):
    """ A function calculating the luminosity density of Lya due to collisional excitation
    n_e, n_HII should be given in cm^-3, T in K
    apu: turn on astropy units or not
    
    """
    
    O = Omega_1s2p(T)
    
    q_exc = O * np.exp(-1.63403376259e-18/(1.38064852e-23 * T)) # in cm^3/s; E_Lya = 1.63403376259e-18 J
    
    return q_exc * n_e * n_HI * 1.63403376259e-11 # in erg/s/cm^3; E_Lya = 1.63403376259e-11 erg
