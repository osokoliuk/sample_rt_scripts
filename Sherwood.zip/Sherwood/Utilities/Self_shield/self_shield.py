import numpy as np

def self_shield_fit_func(z):
    # Fitting values from Rahmati et al. (2013), MNRAS 430(3), 2427-2445
    redshift = np.array([0.0, 1.0, 2.0, 3.0, 4.0, 5.0])
    n_0 = 10**np.array([-2.94, -2.29, -2.06, -2.13, -2.23, -2.35])
    alpha1 = np.array([-3.98, -2.94, -2.22, -1.99, -2.05, -2.63])
    alpha2 = np.array([-1.09, -0.90, -1.09, -0.88, -0.75, -0.57])
    beta = np.array([1.29, 1.21, 1.75, 1.72, 1.93, 1.77])
    fmin1 = np.array([0.99, 0.97, 0.97, 0.96, 0.98, 0.99])

    n_0 = np.interp(z, redshift, n_0)
    alpha1 = np.interp(z, redshift, alpha1)
    alpha2 = np.interp(z, redshift, alpha2)
    beta = np.interp(z, redshift, beta)
    fmin1 = np.interp(z, redshift, fmin1)

    return (n_0, alpha1, alpha2, beta, fmin1)

def self_shield(z, n_H, G_UVB):
    # Fitting function from Rahmati et al. (2013), MNRAS 430(3), 2427-2445
    n_0, alpha1, alpha2, beta, fmin1 = self_shield_fit_func(z)

    G_ph = (fmin1 * (1.0 + (n_H/n_0)**beta)**alpha1 + (1.0-fmin1) * (1.0 + n_H/n_0)**alpha2) * G_UVB
    
    return G_ph

def get_n0(z):
    # Fitting values from Rahmati et al. (2013), MNRAS 430(3), 2427-2445
    redshift = np.array([0.0, 1.0, 2.0, 3.0, 4.0, 5.0])
    n_0 = 10**np.array([-2.94, -2.29, -2.06, -2.13, -2.23, -2.35])

    n_0 = np.interp(z, redshift, n_0)

    return n_0





def alpha_A_HII_Draine2011(T):
    """Case A H II recombination coefficient.
    
    Draine equation 14.5

    """

    return 4.13e-13 * (T/1.0e4)**(-0.7131-0.0115*np.log(T/1.0e4)) # cm^3 s^-1





def Lambda_T(T):
    """
    
    Theuns et al. (1998)

    """

    return 1.17e-10 * (np.sqrt(T) * np.exp(-157809.0/T)) / (np.ones_like(T) + np.sqrt(T/1.0e5)) # cm^3 s^-1





def ion_eq(z, T, n_H, ss=False, Gamma="norm"):
    """
    
    Calculates neutral fraction eta = n_HI/n_H. T and n_H must have the same shape.
    (Gamma_Phot must be either a scalar or also the same shape.)
    
    """
    
    a_A = alpha_A_HII_Draine2011(T)
    L_T = Lambda_T(T)
    
    #treecool_dat = np.loadtxt("/data/curie3/PRACE_ra1865/src_public/planck1_" + key + "/TREECOOL_HM12_G+Q")
    treecool_dat = np.loadtxt("/home/jnw30/Research/Summer/Code/TREECOOL_HM2012")
    
    if Gamma == "norm":
        Gamma_Phot = 10.0**np.interp(np.log10(1.0 + z), treecool_dat[:,0], np.log10(treecool_dat[:,1]), right=-1000.0) # Gamma_H0 in 1/s
    else:
        Gamma_Phots = {"low": 1e-13, "high": 6e-13}
        Gamma_Phot = Gamma_Phots[Gamma]
    
    if ss:
        Gamma_Phot = self_shield(z, n_H, Gamma_Phot)
    
    A = a_A + L_T
    B = 2.0 * a_A + Gamma_Phot/n_H + L_T
    C = a_A
    
    eta = (B - np.sqrt(B**2 - 4.0 * A * C) ) / (2.0 * A)
    
    return eta


