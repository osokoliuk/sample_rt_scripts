# Code for reading snapshots and creating surface brightness maps
#
# Usage:
#
# import snapshot
# snap = snapshot.intmap(80, 512, "_ps13", 9)
# print snap.N_gas
# snap.calc_int()
# snap.save_int("int_map")

import os, sys, inspect
import time

# Find current path
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))

import numpy as np
from astropy.units import Mpc as apu_Mpc
from astropy.cosmology import FlatLambdaCDM

import Sherwood.Utilities.Readsnap.loaddata as ld
import Sherwood.Utilities.Emissivity.recombination_emissivity as rec
import Sherwood.Utilities.Emissivity.excitation_emissivity as exc
import Sherwood.Utilities.Self_shield.self_shield as ss
import Sherwood.Utilities.Grid.put_grid as pgrid

class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'



def conv_eps_SB(eps, snap, z=None, H=None):
    """ Convert luminosity per physical volume to intensity in erg/s/cm^2/sr
    eps_phys should be in erg/s/cm^3, H in s^-1

    """

    if snap != None:
        z = snap.z
        H = snap.H

    SB = eps / (4.0 * np.pi * (1.0 + z)**4)

    SB = SB / (60.0 * 60.0 * 360.0 / (2.0*np.pi))**2 # convert to erg/s/cm^2/arcsec^2

    return SB # in erg/s/cm^2/arcsec^2



def Sstr(S):
    if S == "S":
        return ""
    elif S == "ReS" or S == "ReS2" or S == "ssS":
        return '_' + S
    else:
        raise SystemExit("Error: Sherwood type " + S + " not known.")

def ssstr(ss):
    if ss:
        return ""
    else:
        return "_no_ss"

Gamma_Phots = {"low": 1e-13, "high": 6e-13}

def gstr(Gamma):
    if Gamma == "norm":
        return ""
    elif Gamma == "low" or Gamma == "high":
        return "_G{:.2e}".format(Gamma_Phots[Gamma])





class intmap:

    def __init__(self, size, res, phys, nr, Sherwood="S", zoom=None, nb=None, self_shield=False, nb0=0.0, verbose=True):

        self.size = size
        #self.boxsize = 1e3*float(size)
        self.res = res
        self.phys = phys
        self.nr = nr

        self.Sherwood = Sherwood

        self.key = size + '_' + res + phys + '_' + str(nr) + Sstr(Sherwood)

        self.zoom = zoom
        self.nb = nb

        self.self_shield = self_shield

        self.verbose = verbose

        if self.zoom is None:
            self.zoomds = float(self.size)
        else:
            assert self.zoom[1]-self.zoom[0] - self.zoom[3]-self.zoom[2] < 1e-10
            self.zoomds = float(self.zoom[1]-self.zoom[0])
        
        if self.nb is None:
            self.dl = float(self.size)
        else:
            self.dl = self.nb[1] - self.nb[0]

        # Load snapshot parameters

        self.N_gas, self.N_s, self.N_h, self.z, self.a, self.boxsize, self.omega_m, self.omega_l, self.omega_b, self.omega_dm, self.h, self.h_inv, self.H0, self.H, self.rho_crit0, self.rho_meanb, self.f_H, self.f_He = ld.load(size, res, phys, nr, Sherwood=self.Sherwood, check=True)

        # Set cosmology
        self.cosmo = FlatLambdaCDM(H0=67.8, Om0=0.308)#FlatLambdaCDM(H0=100.0*self.h, Om0=self.omega_m)

        # Number of h^-1 comoving Mpc per arcmin/arcsec
        self.Mpcarcmin = self.h * self.cosmo.kpc_comoving_per_arcmin(self.z).value/1.0e3
        self.Mpcarcsec = self.Mpcarcmin/60.0

        # Set nb if given as width

        if isinstance(self.nb, float):
            self.set_nb(nb, nb0=nb0)





    def set_zoom(self, zoom):

        # Set a new zoom

        self.zoom = zoom

        if self.zoom == None:
            print("\nZoom set to None - size is", float(self.size) / self.Mpcarcmin, "x", float(self.size) / self.Mpcarcmin, "arcmin^2")
            return self.zoom
        
        # Check if it is a square zoom
        dx = self.zoom[1] - self.zoom[0]
        dy = self.zoom[3] - self.zoom[2]
        assert(dx - dy < 1e-10)

        if self.verbose:
            print("\nZoom size set:", self.zoom[1]-self.zoom[0], "h^-1 cMpc (or", (self.zoom[1]-self.zoom[0])/self.Mpcarcmin, "arcmin)")
            print("Zoom centre is x =", np.mean(zoom[:2]), "h^-1 cMpc, y =", np.mean(zoom[2:]), "h^-1 cMpc")

        if self.zoom is None:
            self.zoomds = float(self.size)
        else:
            self.zoomds = float(self.zoom[1]-self.zoom[0])

        return self.zoom





    def set_nb(self, nb, nb0=0.0):

        # Set a new narrowband width

        self.nb = nb
        self.nb0 = nb0

        if isinstance(self.nb, float):
            lambda_Lya = 1.21567e-7 # m
            dlambda = self.nb # (pseudo-)narrowband width in m
            self.dz = dlambda/lambda_Lya

            dl = self.h * (self.cosmo.comoving_distance(self.z+self.dz) - self.cosmo.comoving_distance(self.z)).to(apu_Mpc).value

            self.nb = [nb0-0.5*dl, nb0+0.5*dl]

        self.dl = self.nb[1] - self.nb[0]

        if self.verbose:
            print("\nNarrowband width set:", self.nb[1]-self.nb[0], "h^-1 cMpc")

        if nb0 != 0 and self.verbose:
            print("Narrowband runs from", self.nb[0]%float(self.size), "h^-1 cMpc to", self.nb[1]%float(self.size), "h^-1 cMpc")
            if self.nb[0] < 0:
                print("    (through the boundary at z=0 h^-1 cMpc/z=" + self.size + " h^-1 cMpc)")

        return self.nb





    def load_data(self, data="all", dzoomTF=True, load_mass=False):

        # Begin calculation

        if load_mass:
            pos, poss, posh, M, Ms, Mh, U, rho, ne, nnh, hsml = ld.load(self.size, self.res, self.phys, self.nr, Sherwood=self.Sherwood, zoom=self.zoom, nb=self.nb, dzoomTF=False, load_mass=True, verbose=True)
            return pos, poss, posh, M, Ms, Mh, U, rho, ne, nnh, hsml
        
        if data == "all":
            self.pos, self.poss, self.posh, self.M, self.Ms, self.Mh, self.U, self.rho, self.ne, self.nnh, self.hsml = ld.load(self.size, self.res, self.phys, self.nr, Sherwood=self.Sherwood, zoom=self.zoom, nb=self.nb, dzoomTF=dzoomTF, verbose=self.verbose)
        else:
            self.pos, self.poss, self.posh, self.M, self.Ms, self.Mh, self.U, self.rho, self.ne, self.nnh, self.hsml = ld.load(self.size, self.res, self.phys, self.nr, Sherwood=self.Sherwood, zoom=self.zoom, nb=self.nb, data=data, dzoomTF=dzoomTF, verbose=self.verbose)

        return self.pos, self.poss, self.posh, self.M, self.Ms, self.Mh, self.U, self.rho, self.ne, self.nnh, self.hsml





    def calc_int(self, grid_size=1024, num_threads=512, custom_ionisation=False, narrowband=None, Gamma="norm",
                dens_cut=None, recexc="both", col_dens=False, luminosity_map=False, return_luminosities=False, dzoomTF=True):

        m_H = (1.6737236e-24 * self.z/self.z).astype(np.float64) # in g
        m_He = (6.6464764e-24 * self.z/self.z).astype(np.float64) # in g

        if dens_cut != None and self.verbose:
            crit = np.absolute(dens_cut * self.rho_meanb)
            if dens_cut > 0:
                print("Density cut-off: keeping gas above an overdensity of", dens_cut, "(or physical baryonic density of", crit, "g/cm^3)")
            else:
                print("Density cut-off: keeping gas below an overdensity of", np.absolute(dens_cut))

        self.load_data(data=["pos", "M", "U", "rho", "ne", "nnh", "hsml"], dzoomTF=dzoomTF)

        t0 = time.time()

        # Calculate particle number (density) and temperature

        N_H = self.f_H * self.M / m_H
        N_He = self.f_He * self.M / m_He
        N_e = self.ne * N_H
        N = N_H + N_He + N_e

        n_H = self.f_H * self.rho / m_H # in cm^-3
        n_HI = self.nnh * n_H # in cm^-3
        n_HII = n_H - n_HI # in cm^-3
        n_e = self.ne * n_H # in cm^-3

        V = self.M/self.rho # volume in cm^3

        k_B = (1.38064852e-23 * self.z/self.z).astype(np.float64) # in J/K
        self.T = (2.0 * self.M * self.U) / (3.0 * k_B * N) # in (g * J/g) / (J/K) = K
        del N, N_He, N_e

        if self.self_shield and not custom_ionisation:
            analytical = True

            if analytical:
                print("Self-shielding: Rahmati et al. (2013) post-processing (analytical solution)")

                # Self-shielding implementation from Rahmati et al.:
                # Calculate neutral fraction eta = n_HI/n_H. Note eta = self.nnh
                eta = ss.ion_eq(self.z, self.T, n_H, ss=True, Gamma=Gamma)

                n_HI = n_H * eta
                n_HII = n_H - n_HI

                # Update electron density: subtract original number of e- contributed by H (1-self.nnh) * n_H
                # and add the new number of e- contributed by the self-shielded H, (1-eta) * n_H
                # Originally: n_e = n_e - (1.0 - self.nnh) * n_H + (1.0 - eta) * n_H, this becomes:
                # n_e = n_e + (self.nnh - eta) * n_H
                n_e = 1.08 * n_HII

                # Finally, update the new neutral hydrogen fraction
                self.nnh = eta.copy()
                del eta
            else:
                print("Self-shielding: Rahmati et al. (2013) post-processing (pycool solution)")

                import Utilities.Ionisation_eq.pycool as pycool

                cool = pycool.cooler(h=self.h, omega_m=self.omega_m, omega_b=self.omega_b, f=self.f_H)
                cool.set_photo_rates_from_uvb(self.z)

                Deltas = n_H/(cool.nHcgs_comov_mean * (1.0+self.z)**3)
                
                for parti in range(n_H.size):
                    temp = self.T[parti]
                    Delta = Deltas[parti]

                    # Set values of photoionisation rate from UVB at this redshift
                    cool.set_coefficients(temp, self.z)

                    # Update H photoionisation rate according to Rahmati prescription
                    Gamma_H0_ss = ss.self_shield(self.z, n_H[parti], cool.Gamma_H0)
                    cool.set_photo_rates_manually(Gamma_H0=Gamma_H0_ss, Gamma_He0=cool.Gamma_He0, Gamma_Hep=cool.Gamma_Hep,
                                                eps_H0=cool.eps_H0, eps_He0=cool.eps_He0, eps_Hep=cool.eps_Hep)

                    # Find new ionisation fractions
                    u, nHcgs, n_H0, n_Hp, n_He0, n_Hep, n_Hepp, neperH, mean_mw = cool.find_eq_state_from_temp(Delta, self.z, temp)

                    # Update neutral H and electron fraction/number densities
                    self.nnh[parti] = n_H0
                    n_HI[parti] = n_H0 * n_H
                    n_e[parti] = neperH * n_H
                    
                    del u, nHcgs, n_H0, n_Hp, n_He0, n_Hep, n_Hepp, neperH, mean_mw
                
                del Deltas

                # Update ionised H number density
                n_HII = n_H - n_HI
        else:
            print("No self-shielding included")
        
        if custom_ionisation:
            # Load ionisation grid (created through excursion set method)
            x_HII_grid_size = 128
            grroot = "/data/emergence4/lhw28/for_joris/"
            grid_name = grroot + 'L' + str(self.size) + "_N" + str(self.res) + "/snap" + str(self.nr) + "/xHII_{:d}_z{:.3f}.npy".format(x_HII_grid_size, self.z)
            x_HII_grid = np.load(grid_name)
            
            # Ionised fraction
            x_HII = np.empty(n_H.shape)

            cell_size = float(self.boxsize) / float(x_HII_grid_size) # in h^-1 ckpc

            x_particle = self.pos[:, 0] # in h^-1 ckpc
            y_particle = self.pos[:, 1] # in h^-1 ckpc
            z_particle = self.pos[:, 2] # in h^-1 ckpc

            for n in range(n_H.size):
                i = int(x_particle[n] / cell_size)
                j = int(y_particle[n] / cell_size)
                k = int(z_particle[n] / cell_size)
                x_HII[n] = x_HII_grid[i, j, k]
            
            neutral = x_HII == 0.0
            ionised = x_HII == 1.0

            # For ionised regions, calculate equilibrium neutral fraction eta = n_HI/n_H. Note eta = self.nnh
            self.nnh[ionised] = ss.ion_eq(self.z, self.T[ionised], n_H[ionised], ss=self.self_shield, Gamma=Gamma)
            n_HI[ionised] = n_H[ionised] * self.nnh[ionised]

            # For neutral regions, x_HII = 0 and n_HI/n_H = 1 - x_HII = 1
            self.nnh[neutral] = 1.0 - x_HII[neutral]
            n_HI[neutral] = n_H[neutral] * self.nnh[neutral]
            
            n_HII = n_H - n_HI

            del x_HII, x_HII_grid, x_particle, y_particle, z_particle, neutral, ionised

        if col_dens:
            N_HI = self.nnh * N_H # for column density

        del n_H, N_H

        if dens_cut != None:

            # Cut out gas at overdensities more than a given number of times the mean baryonic density
            crit = np.absolute(dens_cut * self.rho_meanb)
            if dens_cut > 0:
                mask = np.where(self.rho > crit) # keep supercritical gas
            else:
                mask = np.where(self.rho <= crit) # if negative number: keep subcritical gas

            # Update variables needed for emissivity

            n_e = n_e[mask]
            n_HI = n_HI[mask]
            n_HII = n_HII[mask]

            # Update other variables

            if col_dens:
                N_HI = N_HI[mask]

            self.pos = self.pos[mask]
            self.M = self.M[mask]
            self.U = self.U[mask]
            self.rho = self.rho[mask]
            self.ne = self.ne[mask]
            self.nnh = self.nnh[mask]
            self.hsml = self.hsml[mask]
            self.T = self.T[mask]
            V = V[mask]

        # Calculate Ly-a intensities

        eps_rec = rec.eps_recLya(n_e, n_HII, self.T) # in erg/s/cm^3

        eps_exc = exc.eps_excLya(n_e, n_HI, self.T) # in erg/s/cm^3

        invT = np.where(np.isnan(eps_exc))
        eps_exc[invT] = 0.0
        del n_HI, n_HII, invT

        L_rec = (eps_rec * V).astype(np.float64) # physical recombination luminosity in erg/s
        L_exc = (eps_exc * V).astype(np.float64) # physical collisional excitation luminosity in erg/s
        del eps_rec, eps_exc, V

        #eps_phys = eps_rec + eps_exc # total physical luminosity density

        if recexc == "both":
            self.L_phys = L_rec + L_exc # physical luminosity
        elif recexc == "rec":
            self.L_phys = L_rec # just recombination luminosity
        elif recexc == "exc":
            self.L_phys = L_exc # just collisional excitation luminosity

        if self.verbose:
            print("Mean luminosity:", np.mean(self.L_phys, dtype=np.float64), "erg/s")
            print("Total luminosity:", np.sum(self.L_phys, dtype=np.float64), "erg/s")

        if return_luminosities:
            if self.verbose:
                print("Finished luminosity calculation!")
                t1 = time.time()
                ld.print_elapsed_time(t1-t0, process="Calculation")
            return L_rec, L_exc
        else:
            del L_rec, L_exc

        # Project the emissivity (and column density, luminosity) on a grid

        x = self.pos[:, 0] # in h^-1 ckpc
        y = self.pos[:, 1] # in h^-1 ckpc
        h_grid = self.hsml # in h^-1 ckpc

        fieldlength = (1e3 * self.zoomds * self.z/self.z).astype(np.float64) # in h^-1 ckpc

        if self.zoom != None:            
            centerx = 1e3 * np.mean(self.zoom[:2]) # in h^-1 ckpc
            centery = 1e3 * np.mean(self.zoom[2:]) # in h^-1 ckpc
            periodic = 0
        else:
            centerx = 0.5 * fieldlength # in h^-1 ckpc
            centery = 0.5 * fieldlength # in h^-1 ckpc
            periodic = 1

        self.l_slab = (self.a * self.h_inv * self.dl * 3.08567758147e+21).astype(np.float64) # in cm

        kpc_pix = (fieldlength/float(grid_size)).astype(np.float64) # number of h^-1 ckpc per pixel
        l_pix = (self.a * self.h_inv * kpc_pix * 3.08567758147e+21).astype(np.float64) # in cm (fieldlength in h^-1 ckpc)

        if col_dens:
            # Determine column density

            coldens = N_HI/l_pix**2
            del N_HI

            conv = np.mean(coldens, dtype=np.float64)
            value = coldens/conv
            del coldens

            self.col = conv * (pgrid.put_grid(grid_size, centerx, centery, fieldlength, x, y, h_grid, value, periodic=periodic, num_threads=num_threads)).astype(np.float64)

        # Begin intensity conversion

        if narrowband is not None:
            # wl = np.linspace(4000, 9000, 5001) # Angstrom
            # narrowband_profile = np.ones_like(wl) # throughput

            from Utilities.HSC import HSC_filters

            if self.z > 5.6 and self.z < 5.8:
                wl, narrowband_profile = HSC_filters.get_filter_throughput(nbfilter="NB816")
            elif self.z > 6.5 and self.z < 6.7:
                wl, narrowband_profile = HSC_filters.get_filter_throughput(nbfilter="NB921")
            else:
                raise SystemError("redshift not appropriate for use of narrowband filter.")

            from matplotlib import pyplot as plt
            plt.plot(wl, narrowband_profile)
            plt.show()

            # Translate wavelength to distance
            lambda_Lya = 1215.67 # Angstrom

            z = wl/lambda_Lya - 1.0
            dz = z - self.z

            dl = self.h * (self.cosmo.comoving_distance(self.z+dz) - self.cosmo.comoving_distance(self.z)).to(apu_Mpc).value

            plt.plot(dl, narrowband_profile)

            ax_wl = plt.gca().twiny()
            ax_wl.set_xlim(wl[0], wl[-1])
            
            plt.show()

            if self.nb is None:
                cz = 0.5 * float(self.size)
            else:
                cz = 0.5 * (self.nb[1] - self.nb[0])
            
            print(cz)
            z_pos = self.pos[:, 2] / 1e3 # in h^-1 cMpc
            
            # Interpolate attenuation of the narrowband profile with z-position of particles
            narrowband_curve = np.interp(z_pos-cz, dl, narrowband_profile)

            plt.plot(z_pos, narrowband_curve)
            plt.show()

            # Attenuate luminosity contribution given the narrowband curve
            self.L_phys = self.L_phys * narrowband_curve

        conv = np.mean(self.L_phys, dtype=np.float64)
        value = self.L_phys/conv
        del self.L_phys

        Lum = conv * (pgrid.put_grid(grid_size, centerx, centery, fieldlength, x, y, h_grid, value, periodic=periodic, num_threads=num_threads)).astype(np.float64)
        del x, y, h_grid, value

        if luminosity_map:
            self.lum = Lum # projected luminosity; in erg/s/pixel

        # Old method: eps_temp = (Lum/(l_pix**2 * l_slab)).astype(np.float64) # in erg/s/cm^3
        eps_temp = (Lum/l_pix**2).astype(np.float64) # in erg/s/cm^2

        del Lum

        self.pic = conv_eps_SB(eps_temp, self).astype(np.float64)
        del eps_temp

        if self.verbose:
            print("Finished surface brightness calculation!")
            t1 = time.time()
            ld.print_elapsed_time(t1-t0, process="Calculation")

        if luminosity_map:
            if col_dens:
                return self.col, self.lum, self.pic
            else:
                return self.lum, self.pic
        else:
            if col_dens:
                return self.col, self.pic
            else:
                return self.pic





    def overdensity(self):
        
        # Determine overdensity in volume
        
        pos, poss, posh, M, Ms, Mh, U, rho, ne, nnh, hsml = self.load_data(load_mass=True)
        
        t0 = time.time()
        M_inside = np.sum(np.concatenate([M, Ms]), dtype=np.float64) # Mh
        del pos, poss, posh, M, Ms, Mh, U, rho, ne, nnh, hsml

        fieldlength = (1e3 * self.zoomds * self.z/self.z).astype(np.float64) # in h^-1 ckpc

        self.l_slab = (self.a * self.h_inv * self.dl * 3.08567758147e+21).astype(np.float64) # in cm

        comoving_vol = (fieldlength/1e3)**2 * self.dl/1e3
        l_vol = (self.a * self.h_inv * fieldlength * 3.08567758147e+21).astype(np.float64) # fieldlength in cm
        self.volume = l_vol**2 * self.l_slab
        density = M_inside/self.volume
        self.Delta = (density / (self.rho_meanb)).astype(np.float64)
        
        if self.verbose:
            print("\nRegion mass:", M_inside, "g")
            print("Region volume:", self.volume, "cm^3 (or {:.2f} (cMpc/h)^3".format(comoving_vol))
            print("Region density:", density, "g/cm^3")
            print("Overdensity in region:", self.Delta, '\n')

            print("Finished overdensity calculation!")
            t1 = time.time()
            ld.print_elapsed_time(t1-t0, process="Calculation")

        return fieldlength, self.volume, self.Delta





    def save_int(self, pic_name, col_name=None, lum_name=None, Gamma="norm"):

        root = "/data/jnw30/Results/"

        if col_name != None:
            np.save(root + col_name + Sstr(self.Sherwood) + ssstr(self.self_shield) + gstr(Gamma) + ".npy", self.col)

        if lum_name != None:
            np.save(root + lum_name + Sstr(self.Sherwood) + ssstr(self.self_shield) + gstr(Gamma) + ".npy", self.lum)

        np.save(root + pic_name + Sstr(self.Sherwood) + ssstr(self.self_shield) + gstr(Gamma) + ".npy", self.pic)





    def load_int(self, pic_name, col_name=None, lum_name=None, Gamma="norm"):

        root = "/data/jnw30/Results/"

        if self.verbose:
            print()

            if col_name != None:
                print(bcolors.OKBLUE+"Loading column density map from disk:", col_name + Sstr(self.Sherwood) + ssstr(self.self_shield) + gstr(Gamma))
            if lum_name != None:
                print(bcolors.OKBLUE+"Loading luminosity map from disk:", lum_name + Sstr(self.Sherwood) + ssstr(self.self_shield) + gstr(Gamma))

            print(bcolors.OKBLUE+"Loading surface brightness map from disk:", pic_name + Sstr(self.Sherwood) + ssstr(self.self_shield) + gstr(Gamma), '\n', bcolors.ENDC)

        if not os.path.isfile(root + pic_name + Sstr(self.Sherwood) + ssstr(self.self_shield) + gstr(Gamma) + ".npy"):
            raise SystemExit("Error: surface brightness map " + pic_name + Sstr(self.Sherwood) + ssstr(self.self_shield) + gstr(Gamma) + " does not exist.")
        self.pic = np.load(root + pic_name + Sstr(self.Sherwood) + ssstr(self.self_shield) + gstr(Gamma) + ".npy")

        tpl = [self.pic, ]

        if lum_name != None:
            if not os.path.isfile(root + lum_name + Sstr(self.Sherwood) + ssstr(self.self_shield) + gstr(Gamma) + ".npy"):
                raise SystemExit("Error: luminosity map " + lum_name + Sstr(self.Sherwood) + ssstr(self.self_shield) + gstr(Gamma) + " does not exist.")
            self.lum = np.load(root + lum_name + Sstr(self.Sherwood) + ssstr(self.self_shield) + gstr(Gamma) + ".npy")
            tpl = [self.lum, ] + tpl

        if col_name != None:
            if not os.path.isfile(root + col_name + Sstr(self.Sherwood) + ssstr(self.self_shield) + gstr(Gamma) + ".npy"):
                raise SystemExit("Error: column density map " + col_name + Sstr(self.Sherwood) + ssstr(self.self_shield) + gstr(Gamma) + " does not exist.")
            self.col = np.load(root + col_name + Sstr(self.Sherwood) + ssstr(self.self_shield) + gstr(Gamma) + ".npy")
            tpl = [self.col, ] + tpl

        if self.verbose:
            print("Redshift:                            ", self.z)
            print("Hubble constant:                     ", self.H0 * 3.08567758147e+19, "km/s/Mpc (at z=0)")
            print("Hubble constant:                     ", self.H * 3.08567758147e+19, "km/s/Mpc (at z={:.2f})".format(self.z))
            print("Physical critical density:           ", self.rho_crit0, "g/cm^3 (at z=0)")
            print("Physical mean baryon density:        ", self.rho_meanb, "g/cm^3 (at z={:.2f})\n".format(self.z))

            print("Total number of gas particles:       ", self.N_gas)
            print("Total number of stellar particles:   ", self.N_s)
            print("Total number of halo particles:      ", self.N_h)

            print('\n', bcolors.OKGREEN + "Finished loading data from disk!" + bcolors.ENDC)
            print('\n')

        if len(tpl) == 1:
            return tpl[0]
        else:
            return tpl
