import numpy as np

def get_filter_throughput(wl=None, nbfilter="NB816"):
    if wl is None:
        l0 = 7000
        l1 = 11000
        wl = np.linspace(l0, l1, l1-l0+1)

    # Quantum efficiency of FDCCD

    qe_ccd_data = np.loadtxt("/home/jnw30/Research/Summer/xyscan/HSC/qe_ccd_HSC.txt")
    qe_ccd_wl = qe_ccd_data[:, 0]
    qe_ccd = qe_ccd_data[:, 1]

    qe = np.interp(wl, qe_ccd_wl, qe_ccd)

    # Transmittance of the dewar window

    throughput_win_data = np.loadtxt("/home/jnw30/Research/Summer/xyscan/HSC/throughput_win.txt")
    twin_wl = throughput_win_data[:, 0]
    twin = throughput_win_data[:, 1]

    tw = np.interp(wl, twin_wl, twin)

    # Transmittance of the Primary Focus Unit of the HSC (POpt2)

    throughput_pfu_data = np.loadtxt("/home/jnw30/Research/Summer/xyscan/HSC/throughput_popt2.txt")
    pfu_wl = throughput_pfu_data[:, 0]
    pfu = throughput_pfu_data[:, 1]

    pf = np.interp(wl, pfu_wl, pfu)

    # Vignetting has an effect as well...

    # Reflectivity of the Primary Mirror

    mirror_ref_data = np.loadtxt("/home/jnw30/Research/Summer/xyscan/HSC/subaru_m1_r_20190605.txt")
    mref_wl = mirror_ref_data[:, 0]*10 # originally in nm
    mref = np.mean(mirror_ref_data[:, 1:], axis=1)/100.0 # originally in %
    mref_wl = np.sort(mref_wl)
    mref = mref[np.argsort(mref_wl)]

    mr = np.interp(wl, mref_wl, mref)

    if nbfilter == "NB816":
        # NB816

        hsc_nb816_data = np.loadtxt("/home/jnw30/Research/Summer/xyscan/HSC/HSC-NB816.txt")
        hsc_nb816_wl = hsc_nb816_data[:, 0]
        hsc_nb816 = hsc_nb816_data[:, 1]

        nb = np.interp(wl, hsc_nb816_wl, hsc_nb816)

    elif nbfilter == "NB921":
        # NB921

        hsc_nb921_data = np.loadtxt("/home/jnw30/Research/Summer/xyscan/HSC/HSC-NB921.txt")
        hsc_nb921_wl = hsc_nb921_data[:, 0]
        hsc_nb921 = hsc_nb921_data[:, 1]

        nb = np.interp(wl, hsc_nb921_wl, hsc_nb921)

    return (wl, qe*tw*pf*mr*nb)

def get_vignetting(r=None):
    if r is None:
        r = np.arange(0, 0.9, 1000)

    # Vignetting

    vig_data = np.loadtxt("/home/jnw30/Research/Summer/xyscan/HSC/vignetting.txt")
    vig_r = vig_data[:, 0] # degrees
    vig = vig_data[:, 1]

    v = np.interp(r, vig_r, vig)

    return (r, v)

if __name__ == "__main__":
    # Test filter curve at given redshift
    z = 5.7
    h = 0.678 # Hubble parameter

    from astropy import units as u
    from astropy.cosmology import FlatLambdaCDM
    # Set cosmology
    cosmo = FlatLambdaCDM(H0=67.8, Om0=0.308)#FlatLambdaCDM(H0=100.0*self.h, Om0=self.omega_m)

    if z > 5.6 and z < 5.8:
        wl, narrowband_profile = get_filter_throughput(nbfilter="NB816")
    elif z > 6.5 and z < 6.7:
        wl, narrowband_profile = get_filter_throughput(nbfilter="NB921")
    else:
        raise SystemError("redshift not appropriate for use of narrowband filter.")

    # Translate wavelength to distance
    lambda_Lya = 1215.67 # Angstrom

    z_wl = wl/lambda_Lya - 1.0
    dz = z_wl - z

    dl = h * (cosmo.comoving_distance(z+dz) - cosmo.comoving_distance(z)).to(u.Mpc).value

    from matplotlib import pyplot as plt
    plt.plot(dl, narrowband_profile)

    ax_wl = plt.gca().twiny()
    ax_wl.set_xlim(wl[0], wl[-1])

    plt.show()