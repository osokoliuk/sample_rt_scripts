import numpy as np
from astropy import units as u
from astropy.io import fits

import read_FITS

from matplotlib import pyplot as plt
import seaborn as sns

test = False



class MUSE_err:

    def __init__(self, units="MUSE", plot=False, verbose=False):
        self.units = units
        self.plot = plot
        self.verbose = verbose

        if plot:
            sns.set_style("ticks")

        self.root = "/data/jnw30/Data/MUSE/"

        self.filename = self.root + "DATACUBE-HDFS-1.34.fits"

        with read_FITS.F(self.filename, self.verbose) as HDFS:
            self.cube_data, self.cube_var = HDFS.read_data()
            self.MUSE_w = HDFS.get_wl()

        self.cube_data_nb = None # not selected yet
        self.cube_var_nb = None

        if units != "MUSE":
            self.omega_pix = 0.2**2 # solid angle of MUSE pixel in arcsec^2
        if units == "nuI_nu":
            self.omega_pix = (self.omega_pix * u.arcsec**2).to(u.sr).value # from arcsec^2 to sr
        #print omega_pix

        if units == "SB":
            '''MUSE_nu = 299792458.0/self.MUSE_w
            MUSE_nu = MUSE_nu.reshape((-1, 1, 1))
            print MUSE_nu, MUSE_nu.shape'''

            self.cube_data *= 1e-20 # now in erg/s/cm^2/Angstrom
            self.cube_data /= self.omega_pix # now in erg/s/cm^2/arcsec^2/Angstrom or erg/s/cm^2/sr/Angstrom
            #self.cube_data = 299792458.0/MUSE_nu**2 * self.cube_data # convert I_l to I_nu

            self.cube_var *= 1e-20 # now in erg/s/cm^2/Angstrom
            self.cube_var /= self.omega_pix # now in erg/s/cm^2/arcsec^2/Angstrom or erg/s/cm^2/sr/Angstrom
            #self.cube_var = 299792458.0/MUSE_nu**2 * self.cube_var # convert I_l to I_nu

        wlfile = self.root + "IMAGE-HDFS-1.34.fits"

        wl = fits.open(wlfile)
        if self.verbose:
            print('\n', '\n', "White light image:", '\n')
            wl.info()
            print('\n')

        self.wl_data = wl[1].data
        #self.wl_var = wl[2].data
        wl.close()

        self.mask = np.where(self.wl_data > 0.20)





    def select_nb(self, z=2.80, nb_idx=None, nb_lambda=None, nb=8.75e-10, cont_subt=False, test_pl=False, verbose=None):
        if verbose != None:
            self.verbose = verbose

        self.cont_subt = cont_subt

        Lya_w = 121.567 # nm

        z_MUSE = self.MUSE_w/Lya_w - 1.0

        if self.verbose:
            #print "MUSE redshifts:", z_MUSE
            pass #print '\n'

        if nb_idx == None and nb_lambda == None:
            nb_idx = np.argmin(np.abs(z_MUSE - z))
            if self.verbose:
                print("Closest MUSE nb index:", nb_idx)
                print("Corresponding wavelength:", self.MUSE_w[nb_idx])
                print("Corresponding redshift:", z_MUSE[nb_idx])
        elif nb_idx != None:
            if self.verbose:
                print("Index chosen:", nb_idx)
                print("Wavelength:", self.MUSE_w[nb_idx])
                print("Redshift:", z_MUSE[nb_idx])
        elif nb_lambda != None:
            nb_idx = np.argmin(np.abs(self.MUSE_w - nb_lambda))
            if self.verbose:
                print("Closest MUSE nb index:", nb_idx)
                print("Corresponding wavelength:", self.MUSE_w[nb_idx])
                print("Corresponding redshift:", z_MUSE[nb_idx])

        # Select a narrowband (of 8.75 A by default)

        #cube_data = cube_data[0:7]
        #cube_var = cube_var[0:7]

        nb_spc = int(round(nb/1.25e-10)) # MUSE spaxels are 1.25 Angstrom
        if self.verbose:
            print("Narrowband spans", nb_spc, "indices")
            print('\n')

        if nb_idx+nb_spc > 3565: #self.cube_data.shape[0]-1: # if nb_idx+nb_spc is larger than largest possible index # EDIT: don't go above z=6.57 because of skylines
            #nb_idx = (self.cube_data.shape[0] - 1) - nb_spc # set it so that nb_idx+nb_spc is exactly the last index possible, self.cube_data.shape[0] - 1
            nb_idx = 3565 # set to z=6.57; the very end of the MUSE cube contains skylines
            if self.verbose:
                print("MUSE nb index chosen instead:", nb_idx)
                print("Redshift at this index:", z_MUSE[nb_idx])

        self.cube_data_nb = self.cube_data[nb_idx:nb_idx+nb_spc]
        self.cube_var_nb = self.cube_var[nb_idx:nb_idx+nb_spc]

        self.nb_idx = nb_idx
        self.nb_spc = nb_spc

        self.z_nb = z_MUSE[nb_idx]

        # Integrate over the narrowband

        if test_pl:
            vmin, vmax = -21, -16

        if test_pl:
            plt.figure()
            im = plt.imshow(np.log10(np.nansum(self.cube_data_nb, axis=0)), vmin=vmin, vmax=vmax, cmap="jet", origin="lower")
            plt.colorbar(im)
            plt.title("Nansum")
            plt.show()

        if test_pl:
            plt.figure()
            im = plt.imshow(np.log10(np.nanmedian(self.cube_data_nb, axis=0)), vmin=vmin, vmax=vmax, cmap="jet", origin="lower")
            plt.colorbar(im)
            plt.title("Nanmedian")
            plt.show()

        if self.cont_subt:
            cube_cont = self.calc_cont()

            if test_pl:
                plt.figure()
                im = plt.imshow(np.log10(cube_cont), vmin=vmin, vmax=vmax, cmap="jet", origin="lower")
                plt.colorbar(im)
                plt.title("Continuum (nanmedian)")
                plt.show()

            # Continuum subtraction
            self.cube_data_nb -= np.tile(cube_cont, (self.nb_spc, 1, 1))

        # Integrate the specific intensity over the wavelength range; nb now in units of erg/s/cm^2/arcsec^2
        self.cube_data_nb = np.trapz(self.cube_data_nb, dx=1.25, axis=0) #before: np.sum(self.cube_data_nb, axis=0)

        if test_pl:
            plt.figure()
            im = plt.imshow(np.log10(self.cube_data_nb), vmin=vmin, vmax=vmax, cmap="jet", origin="lower")
            plt.colorbar(im)
            plt.title("Continuum subtracted and integrated SB")
            plt.show()

        return z_MUSE[nb_idx], z_MUSE[nb_idx+nb_spc]




    def calc_cont(self, width_min=5, width_plus=5, verbose=None):
        if verbose != None:
            self.verbose = verbose

        if type(self.cube_data_nb) == type(None):
            raise SystemError("Error: no narrowband set yet")

        if self.nb_idx-width_min < 0:
            # If nb_idx-width_min is smaller than smallest possible index,
            # change the continuum region to larger wavelengths
            dpix = width_min - self.nb_idx
            if self.verbose:
                print("Continuum shifted redwards by", dpix, "pixels")
            width_min -= dpix
            width_plus += dpix

        if self.nb_idx+self.nb_spc+width_plus > self.cube_data.shape[0]-1:
            # If nb_idx+nb_spc+width_plus is larger than largest possible index,
            # change the continuum region to smaller wavelengths
            dpix = (self.nb_idx+self.nb_spc+width_plus) - (self.cube_data.shape[0]-1)
            if self.verbose:
                print("Continuum shifted bluewards by", dpix, "pixels")
            width_min += dpix
            width_plus -= dpix

        self.cube_data_cont = np.concatenate((self.cube_data[self.nb_idx-width_min:self.nb_idx], self.cube_data[self.nb_idx+self.nb_spc:self.nb_idx+self.nb_spc+width_plus]), axis=0)

        self.cube_data_cont = np.nanmedian(self.cube_data_cont, axis=0) # in units of erg/s/cm^2/arcsec^2/Angstrom (before: self.nb_spc * ...)

        return self.cube_data_cont





    def hist_fit(self, n_bins=int(1e4), verbose=False, plot=False):
        if type(self.cube_data_nb) == type(None):
            raise SystemError("Error: no narrowband set yet")

        cube_data_nb_hf = self.cube_data_nb[18:331-13, 15:326-11]

        PSF_sig = (1.5/0.2)/(2.0 * np.sqrt(2.0 * np.log(2.0))) # from FWHM to sigma (for a Gaussian)

        # Convolve
        import scipy.ndimage as ndimage
        # cube_data_nb_hf = ndimage.filters.gaussian_filter(cube_data_nb_hf, sigma=PSF_sig, order=0, mode='nearest', truncate=5.0)
        
        # plt.figure()
        # im = plt.imshow(np.log10(cube_data_nb_hf), vmin=-21, vmax=-16, cmap="jet", origin="lower")
        # plt.colorbar(im)
        # plt.title("PSF convolved narrowband")
        # plt.show()

        # Look at histogram of pixel values

        if plot or self.plot:
            plt.figure()
            n, bins, patches = plt.hist(cube_data_nb_hf.flatten(), bins=n_bins, histtype='step', color='b', label="Histogram")
        else:
            n, bins = np.histogram(cube_data_nb_hf.flatten(), bins=n_bins)

        x_bins = bins[:-1] + np.tile(bins[1]-bins[0], len(bins)-1) # bin centres

        #print x_bins[np.where(n<x_bins/1e4)][0], x_bins[np.where(n<x_bins/1e4)][-1]
        crit = min(x_bins[np.where(n<n_bins/1e3)][0], x_bins[np.where(n<n_bins/1e3)][-1])

        crit = 10.0
        if self.units == "SB":
            crit = 3e-18

        select = np.where((x_bins > -crit) * (x_bins < crit))
        if plot or self.plot:
            plt.plot(x_bins[select], n[select], drawstyle='steps-mid', linewidth=2.0, color='r', label="Fitted region")

        def Gaussian(x, a, x0, sigma):
            return a/(np.sqrt(2*np.pi)*sigma) * np.exp(-(x-x0)**2 / (2.0*sigma**2))

        from scipy.optimize import curve_fit
        popt, pcov = curve_fit(Gaussian, x_bins[select], n[select], p0=[1.0, 0.04*crit, 0.4*crit]) #, bounds=([-np.inf, -np.inf, 0.0], [np.inf, np.inf, np.inf]))

        self.sigma = popt[2]

        if verbose or self.verbose:
            print("Fitted sigma:", self.sigma)
            print('\n')

        if plot or self.plot:
            plt.plot(x_bins[select], Gaussian(x_bins[select], popt[0], popt[1], popt[2]), color='g', label="Gaussian fit $a / \\sqrt{2\\pi} \\, e^{-(x - x_0)^2 / (2 \\sigma^2)}$:")
            plt.plot(0, 0, linewidth=0.0, label="$a=${:.2e}, $x_0=${:.2e}, $\\sigma=${:.2e}".format(popt[0], popt[1], popt[2]))

            plt.yscale("log")
            plt.xlim(-3*crit, 20*crit)
            plt.legend()
            plt.savefig(self.root + "hist_{:.2f}".format(self.z_nb) + ".pdf")
            #plt.draw()
            plt.show(block=False)



        return self.sigma





    def make_sigma_nb(self, wl_mask=False, mask2=True):
        sigma = np.sum(self.cube_var_nb, axis=0)
        if self.verbose:
            print(sigma.shape)

        if wl_mask:
            sigma[self.mask] = np.nan

        sigma = np.sqrt(sigma)[18:331-13, 15:326-11]
        #print np.nanmean(sigma), np.nanmedian(sigma), np.nanmin(sigma), np.nanmax(sigma)
        #print sigma.shape


        #print np.nanmean(sigma), np.nanmin(sigma), np.nanmax(sigma)
        if mask2:
            mask2 = np.where(sigma > 5.0)
            sigma[mask2] = np.mean(sigma)

        vmin = 0.0
        vmax = 1.0

        if self.plot:
            plt.figure()
            im = plt.imshow(np.log10(sigma), vmin=vmin, vmax=vmax, origin="lower")
            plt.colorbar(im)
            plt.savefig(self.root + "sigma.pdf")
            #plt.draw()
            plt.show(block=False)

        if self.verbose:
            print("Mean sigma in MUSE units:", np.nanmean(sigma))

        #print np.nanmean(sigma), np.nanmedian(sigma), np.nanmin(sigma), np.nanmax(sigma)

        np.save(self.root + "sigma.npy", sigma)

        return np.nanmean(sigma)



if test:
    units="SB"
    s = MUSE_err(units=units, plot=True, verbose=True)
    s.select_nb(z=5.75595334669, nb=3.75e-10, cont_subt=True, test_pl=True)
    #s.hist_fit()
    #err = s.make_sigma_nb(mask2=True) # mask2 doesn't seem to make much difference: 2.677 (True) vs. 2.682 (False)
    #print err

    #print s.cube_var.shape[0]

    s.hist_fit()
    plt.show()

    '''
    #z1, z2 = s.select_nb(nb_idx=1075, nb=8*1.25e-10)
    z1, z2 = s.select_nb(nb_lambda=609.3, nb=8*1.25e-10)
    print z1, z2
    cube_cont = s.calc_cont(width_min=5, width_plus=5)
    s.hist_fit()

    pic = np.sum(s.cube_data_nb, axis=0) - cube_cont # subtract continuum
    pic = pic[18:331-13, 15:326-11] # select 300x300 image

    plt.figure()
    plt.imshow(np.log10(pic), cmap="jet", origin="lower")
    plt.show()
    '''
