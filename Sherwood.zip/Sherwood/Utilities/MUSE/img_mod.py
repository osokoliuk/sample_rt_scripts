import numpy as np
from astropy import units as u
import scipy.ndimage as ndimage
import MUSE.MUSE_error as MUSE_error

def Gauss_conv(pic, snap, grid_size, PSF_fact=1.0, PSF_arcsec=None):

    # Convolve image with 2D Gaussian (zoom, boxsize must be given)

    if snap.zoom != None:
        dx = snap.zoom[1] - snap.zoom[0]
        dy = snap.zoom[3] - snap.zoom[2]
        assert(dx - dy < 1e-10)
        fieldlength = 1e3 * dx # in h^-1 ckpc
    else:
        fieldlength = snap.boxsize # in h^-1 ckpc

    # Determine scale conversion of distance/pixel
    kpc_pix = fieldlength/float(grid_size) # number of h^-1 ckpc per pixel
    Mpc_pix = kpc_pix/1e3

    # Convert MUSE FWHM to PSF standard deviation

    if PSF_arcsec is None:
        MUSE_FWHM = 0.75 # in arcsec, 0.75 at z~2.8 and 0.6 at z~6.65 (blue spectrum end) - see Bacon et al. (2015), MUSE HDFS
    else:
        MUSE_FWHM = PSF_arcsec # force PSF FWHM to be a given number of arcsec
    
    MUSE_FWHM *= snap.Mpcarcsec # in h^-1 cMpc
    MUSE_FWHM /= Mpc_pix # convert from h^-1 cMpc to pixels

    PSF_sig = MUSE_FWHM/(2.0 * np.sqrt(2.0 * np.log(2.0))) # from FWHM to sigma (for a Gaussian)

    # Multiply by factor of ...
    PSF_sig *= PSF_fact

    # Convolve
    if snap.zoom == None: # if periodic = 1/True
        pic = ndimage.filters.gaussian_filter(pic, sigma=PSF_sig, order=0, mode='reflect', truncate=5.0)
    else:
        pic = ndimage.filters.gaussian_filter(pic, sigma=PSF_sig, order=0, mode='nearest', truncate=5.0)

    return pic





def add_noise(pic, snap, grid_size, dlambda, units, cont_subt, z=None, noise="MUSE", mult_fact=1.0, plot=False, verbose=True):

    if z == None:
        z = snap.z

    # Add noise to image (zoom, boxsize must be given)

    if snap.zoom != None:
        dx = snap.zoom[1] - snap.zoom[0]
        dy = snap.zoom[3] - snap.zoom[2]
        assert(dx - dy < 1e-10)
        fieldlength = 1e3 * dx # in h^-1 ckpc
    else:
        fieldlength = snap.boxsize # in h^-1 ckpc

    ns_size = (fieldlength/1e3)/(0.2*snap.Mpcarcsec) # number of MUSE pixels (0.2 arcsec) in fieldlength
    #print grid_size, ns_size

    # Ratio of pixels per MUSE pixel
    ns_ratio = grid_size/ns_size

    if noise == "MUSE":
        # Read in MUSE cube
        s = MUSE_error.MUSE_err(units=units, verbose=verbose)
        s.select_nb(z=z, nb=dlambda, cont_subt=cont_subt)
        scale = s.hist_fit(plot=plot) # from Gaussian fit, in erg/s/cm^2/arcsec^2 or erg/s/cm^2/sr (depending on value of units)

        # Noise per pixel increases as sqrt(A) where A is the area of a pixel
        scale *= ns_ratio # scale noise
        # Multiply by given factor
        scale *= mult_fact

        sigma = np.random.normal(scale=scale, size=(grid_size, grid_size))
    else:
        scale = noise

        sigma = np.random.normal(scale=scale, size=pic.shape)

    pic += sigma

    return pic, scale
