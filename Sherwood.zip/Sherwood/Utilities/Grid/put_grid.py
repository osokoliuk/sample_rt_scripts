import numpy as np
import ctypes as ct
import time
import os

def put_grid (grid_size, centerx, centery, fieldlength, x , y, h, value, periodic, num_threads=1):   
  start = time.time()
  
  libpath = os.path.dirname(os.path.abspath(__file__)) + "/"
  
  lp = np.ctypeslib.load_library('libpython_project.so', libpath)

  if num_threads == 1:
    lp.put_1minusrsquaredsquared.argtypes = [np.ctypeslib.ndpointer(), ct.c_int, ct.c_int, np.ctypeslib.ndpointer(), np.ctypeslib.ndpointer(), np.ctypeslib.ndpointer(), np.ctypeslib.ndpointer(), ct.c_int]
    lp.put_1minusrsquaredsquared.restype = ct.c_int
  else:
    lp.put_grid_threads.argtypes = [ct.c_int, np.ctypeslib.ndpointer(), ct.c_int, ct.c_int, np.ctypeslib.ndpointer(), np.ctypeslib.ndpointer(), np.ctypeslib.ndpointer(), np.ctypeslib.ndpointer(), ct.c_int]
    lp.put_grid_threads.restype = ct.c_int

  array = np.zeros((grid_size,grid_size), dtype=np.float32, order='C')
  
  num_part = x.__len__()
  assert y.__len__() == num_part
  assert h.__len__() == num_part
  assert value.__len__() == num_part

  xpix = np.float32( ( x - (centerx - 0.5*fieldlength) ) / ( np.float32(fieldlength) / grid_size ) - 0.5 ) # x=0 corresponds to beginning of first pixel, x = fieldlenght to end of last pixel 
  ypix = np.float32( ( y - (centery - 0.5*fieldlength) ) / ( np.float32(fieldlength) / grid_size ) - 0.5 )
  hpix = np.float32( h / ( np.float32(fieldlength) / grid_size ) )
  valuefloat = np.float32( value ) 

  assert xpix.flags['C_CONTIGUOUS']
  assert ypix.flags['C_CONTIGUOUS']
  assert hpix.flags['C_CONTIGUOUS']
  assert valuefloat.flags['C_CONTIGUOUS']

  assert periodic in [0,1]

  if num_threads == 1:
    count = lp.put_1minusrsquaredsquared(array, grid_size, num_part, valuefloat, xpix, ypix, hpix, periodic)
  else:
    count = lp.put_grid_threads(num_threads, array, grid_size, num_part, valuefloat, xpix, ypix, hpix, periodic)

  fin = time.time()
  
  if num_threads == 1:
    print count,"particles put on grid in",fin-start,"seconds"
  else:
    print count,"particles put on grid in",fin-start,"seconds using",num_threads,"threads"

  return array
  
def put_grid_cic2D (grid_size, centerx, centery, fieldlength, x , y, value, periodic):
  start = time.time()

  assert periodic in [0,1]

  libpath = os.path.dirname(os.path.abspath(__file__)) + "/"

  lp = np.ctypeslib.load_library('libpython_project.so', libpath)

  lp.put_grid_cic2D.argtypes = [np.ctypeslib.ndpointer(), ct.c_int, ct.c_int, np.ctypeslib.ndpointer(), np.ctypeslib.ndpointer(), np.ctypeslib.ndpointer(), ct.c_int]
  lp.put_grid_cic2D.restype = ct.c_int
  
  array = np.zeros((grid_size,grid_size), dtype=np.float32, order='C')
  
  num_part = x.__len__()
  assert y.__len__() == num_part
  assert value.__len__() == num_part

  xpix = np.float32( ( x - (centerx - 0.5*fieldlength) ) / ( np.float32(fieldlength) / grid_size ) - 0.5 ) # x=0 corresponds to beginning of first pixel, x = fieldlenght to end of last pixel 
  ypix = np.float32( ( y - (centery - 0.5*fieldlength) ) / ( np.float32(fieldlength) / grid_size ) - 0.5 )
  valuefloat = np.float32( value )

  assert xpix.flags['C_CONTIGUOUS']
  assert ypix.flags['C_CONTIGUOUS']
  assert valuefloat.flags['C_CONTIGUOUS']
  
  count = lp.put_grid_cic2D(array, grid_size, num_part, valuefloat, xpix, ypix, periodic)

  fin = time.time()
  
  print count, "particles put on 2D grid in", fin-start, "seconds"
  
  return array
  
def put_grid_cic3D (grid_size, centerx, centery, centerz, fieldlength, x , y, z, value):
  start = time.time()

  libpath = os.path.dirname(os.path.abspath(__file__)) + "/"
  
  lp = np.ctypeslib.load_library('libpython_project.so', libpath)

  lp.put_grid_cic3D.argtypes = [np.ctypeslib.ndpointer(), ct.c_int, ct.c_int, np.ctypeslib.ndpointer(), np.ctypeslib.ndpointer(), np.ctypeslib.ndpointer(), np.ctypeslib.ndpointer()]
  lp.put_grid_cic3D.restype = ct.c_int
  
  array = np.zeros((grid_size,grid_size,grid_size), dtype=np.float32, order='C')
  
  num_part = x.__len__()
  assert y.__len__() == num_part
  assert z.__len__() == num_part
  assert value.__len__() == num_part

  xpix = np.float32( ( x - (centerx - 0.5*fieldlength) ) / ( np.float32(fieldlength) / grid_size ) - 0.5 ) # x=0 corresponds to beginning of first pixel, x = fieldlenght to end of last pixel 
  ypix = np.float32( ( y - (centery - 0.5*fieldlength) ) / ( np.float32(fieldlength) / grid_size ) - 0.5 )
  zpix = np.float32( ( z - (centerz - 0.5*fieldlength) ) / ( np.float32(fieldlength) / grid_size ) - 0.5 )
  valuefloat = np.float32( value )

  assert xpix.flags['C_CONTIGUOUS']
  assert ypix.flags['C_CONTIGUOUS']
  assert zpix.flags['C_CONTIGUOUS']
  assert valuefloat.flags['C_CONTIGUOUS']
  
  count = lp.put_grid_cic3D(array, grid_size, num_part, valuefloat, xpix, ypix, zpix)

  fin = time.time()
  
  print count, "particles put on 3D grid in", fin-start, "seconds"
  
  return array


